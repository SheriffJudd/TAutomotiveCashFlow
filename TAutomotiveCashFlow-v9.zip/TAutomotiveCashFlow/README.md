# T Automotive Cash Flow v9

Version 9 is the pre-live bookkeeping cleanup release.

## v9 highlights
- Custom income and expense categories in Settings.
- Add, rename, archive and restore categories without rebuilding the app.
- Renaming a category also updates existing transactions using that category.
- Category settings are included in verified ZIP backups and restored with v9 backups.
- Cleaner default bookkeeping categories:
  - Income: Labour & services, Parts / tyre sales, Call-out, Other income.
  - Expenses: Parts & materials, Fuel, Tools & equipment, Vehicle costs, Insurance, Subcontractors, Software / subscriptions, Phone / internet, Advertising, Professional fees, Bank charges, Rent / storage, Other expense.
- Payment method is now a simple selector: Bank transfer, Cash, Card, Other or Not specified.
- Customer/Supplier label changes automatically depending on income or expense.
- Description is required for each transaction.
- Receipt attachment is shown primarily for expenses.
- Android launcher name shortened to `T Automotive`; the app remains T Automotive Cash Flow internally.
- Existing backup, restore, CSV, PDF, tax-year, starting-balance and tracked-balance features remain intact.

Version code: 9
Version name: 9.0
