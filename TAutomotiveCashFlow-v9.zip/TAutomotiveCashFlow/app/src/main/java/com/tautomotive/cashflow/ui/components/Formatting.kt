package com.tautomotive.cashflow.ui.components

import java.text.NumberFormat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

private val gbp = NumberFormat.getCurrencyInstance(Locale.UK)
private val dateFormatter = DateTimeFormatter.ofPattern("dd MMM yyyy")

fun formatMoney(pence: Long): String = gbp.format(pence / 100.0)
fun formatDate(date: LocalDate): String = date.format(dateFormatter)
