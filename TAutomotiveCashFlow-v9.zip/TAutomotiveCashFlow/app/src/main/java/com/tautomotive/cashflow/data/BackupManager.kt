package com.tautomotive.cashflow.data

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.Instant
import java.time.LocalDate
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream


data class BackupData(
    val transactions: List<MoneyTransaction>,
    val openingBalance: OpeningBalance?,
    val categorySettings: CategorySettings? = null
)

object BackupManager {
    private const val JSON_NAME = "transactions.json"
    private const val SETTINGS_NAME = "settings.json"
    private const val CSV_NAME = "transactions.csv"
    private const val MANIFEST_NAME = "manifest.json"
    private const val BACKUP_FORMAT_VERSION = 3

    /**
     * Creates the complete ZIP in a temporary file, validates it, copies it to
     * the chosen destination, then reads the destination back and validates it
     * again. A success result therefore means the saved file was readable and
     * structurally valid at the time it was written.
     */
    fun export(
        context: Context,
        transactions: List<MoneyTransaction>,
        openingBalance: OpeningBalance?,
        categorySettings: CategorySettings,
        outputUri: Uri
    ) {
        val temp = File.createTempFile("cashflow_backup_", ".zip", context.cacheDir)
        try {
            writeBackupFile(context, transactions, openingBalance, categorySettings, temp)
            validateFile(temp, requireManifest = true)

            val output = context.contentResolver.openOutputStream(outputUri, "w")
                ?: error("Could not open backup destination")
            output.use { out -> temp.inputStream().use { it.copyTo(out) } }

            // Verify the exact file that was saved to the provider/folder.
            validateUri(context, outputUri)
        } finally {
            temp.delete()
        }
    }

    fun exportCsv(
        context: Context,
        transactions: List<MoneyTransaction>,
        outputUri: Uri
    ) {
        val output = context.contentResolver.openOutputStream(outputUri, "w")
            ?: error("Could not open CSV destination")
        output.bufferedWriter(Charsets.UTF_8).use { writer ->
            writer.write(csvText(transactions))
        }
    }

    fun validateUri(context: Context, uri: Uri) {
        val temp = File.createTempFile("cashflow_validate_", ".zip", context.cacheDir)
        try {
            val input = context.contentResolver.openInputStream(uri)
                ?: error("Could not read the saved backup")
            input.use { source -> temp.outputStream().use { source.copyTo(it) } }
            validateFile(temp, requireManifest = true)
        } finally {
            temp.delete()
        }
    }

    fun import(context: Context, inputUri: Uri): BackupData {
        val tempZip = File.createTempFile("cashflow_restore_", ".zip", context.cacheDir)
        val tempDir = File(context.cacheDir, "cashflow_restore_${System.currentTimeMillis()}").apply { mkdirs() }
        try {
            val input = context.contentResolver.openInputStream(inputUri) ?: error("Could not open backup file")
            input.use { source -> tempZip.outputStream().use { source.copyTo(it) } }

            // Older v2-v6 backups did not contain a manifest. They remain
            // restorable, but all core JSON is still parsed before any DB swap.
            validateFile(tempZip, requireManifest = false)

            val basePath = tempDir.canonicalPath + File.separator
            ZipInputStream(tempZip.inputStream().buffered()).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    val target = File(tempDir, entry.name)
                    if (!target.canonicalPath.startsWith(basePath)) error("Invalid backup file")
                    if (entry.isDirectory) {
                        target.mkdirs()
                    } else {
                        target.parentFile?.mkdirs()
                        target.outputStream().use { zip.copyTo(it) }
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }

            val jsonFile = File(tempDir, JSON_NAME)
            if (!jsonFile.exists()) error("Backup does not contain transactions")
            val array = JSONArray(jsonFile.readText())

            // Parse everything first. Receipt files are copied only after the
            // transaction data has been proven readable.
            val transactions = buildList {
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val receipt = obj.optString("receiptFileName", "")
                    add(
                        MoneyTransaction(
                            id = obj.optLong("id", 0L),
                            type = TransactionType.valueOf(obj.getString("type")),
                            amountPence = obj.getLong("amountPence"),
                            category = obj.getString("category"),
                            description = obj.optString("description", ""),
                            date = LocalDate.parse(obj.getString("date")),
                            paymentMethod = obj.optString("paymentMethod", ""),
                            customerSupplier = obj.optString("customerSupplier", ""),
                            jobReference = obj.optString("jobReference", ""),
                            vehicleRegistration = obj.optString("vehicleRegistration", ""),
                            notes = obj.optString("notes", ""),
                            receiptFileName = receipt
                        )
                    )
                }
            }

            val settingsFile = File(tempDir, SETTINGS_NAME)
            val settingsJson = if (settingsFile.exists()) JSONObject(settingsFile.readText()) else null
            val openingBalance = settingsJson?.let { settings ->
                val dateText = settings.optString("openingBalanceDate", "")
                if (dateText.isNotBlank() && settings.has("openingBalancePence")) {
                    OpeningBalance(
                        amountPence = settings.getLong("openingBalancePence"),
                        date = LocalDate.parse(dateText)
                    )
                } else null
            }

            fun jsonList(json: JSONObject, key: String): List<String>? {
                val array = json.optJSONArray(key) ?: return null
                return buildList { for (i in 0 until array.length()) add(array.getString(i)) }
            }

            val categorySettings = settingsJson?.let { settings ->
                val income = jsonList(settings, "incomeCategories")
                val expense = jsonList(settings, "expenseCategories")
                if (income != null && expense != null) {
                    CategorySettings(
                        incomeCategories = income,
                        expenseCategories = expense,
                        archivedIncomeCategories = jsonList(settings, "archivedIncomeCategories") ?: emptyList(),
                        archivedExpenseCategories = jsonList(settings, "archivedExpenseCategories") ?: emptyList()
                    )
                } else null
            }

            val receiptSourceDir = File(tempDir, "receipts")
            if (receiptSourceDir.exists()) {
                receiptSourceDir.listFiles()?.filter { it.isFile }?.forEach { source ->
                    source.copyTo(ReceiptStorage.file(context, source.name), overwrite = true)
                }
            }

            val finalTransactions = transactions.map { transaction ->
                val receipt = transaction.receiptFileName
                if (receipt.isNotBlank() && ReceiptStorage.file(context, receipt).exists()) transaction
                else transaction.copy(receiptFileName = "")
            }

            return BackupData(transactions = finalTransactions, openingBalance = openingBalance, categorySettings = categorySettings)
        } finally {
            tempZip.delete()
            tempDir.deleteRecursively()
        }
    }

    private fun writeBackupFile(
        context: Context,
        transactions: List<MoneyTransaction>,
        openingBalance: OpeningBalance?,
        categorySettings: CategorySettings,
        file: File
    ) {
        val receipts = transactions.map { it.receiptFileName }
            .filter { it.isNotBlank() }
            .distinct()
            .map { ReceiptStorage.file(context, it) }
            .filter { it.exists() && it.isFile }

        ZipOutputStream(file.outputStream().buffered()).use { zip ->
            val array = JSONArray()
            transactions.forEach { t ->
                array.put(
                    JSONObject()
                        .put("id", t.id)
                        .put("type", t.type.name)
                        .put("amountPence", t.amountPence)
                        .put("category", t.category)
                        .put("description", t.description)
                        .put("date", t.date.toString())
                        .put("paymentMethod", t.paymentMethod)
                        .put("customerSupplier", t.customerSupplier)
                        .put("jobReference", t.jobReference)
                        .put("vehicleRegistration", t.vehicleRegistration)
                        .put("notes", t.notes)
                        .put("receiptFileName", t.receiptFileName)
                )
            }
            zip.putNextEntry(ZipEntry(JSON_NAME))
            zip.write(array.toString(2).toByteArray(Charsets.UTF_8))
            zip.closeEntry()

            val settings = JSONObject()
            if (openingBalance != null) {
                settings.put("openingBalancePence", openingBalance.amountPence)
                settings.put("openingBalanceDate", openingBalance.date.toString())
            }
            settings.put("incomeCategories", JSONArray(categorySettings.incomeCategories))
            settings.put("expenseCategories", JSONArray(categorySettings.expenseCategories))
            settings.put("archivedIncomeCategories", JSONArray(categorySettings.archivedIncomeCategories))
            settings.put("archivedExpenseCategories", JSONArray(categorySettings.archivedExpenseCategories))
            zip.putNextEntry(ZipEntry(SETTINGS_NAME))
            zip.write(settings.toString(2).toByteArray(Charsets.UTF_8))
            zip.closeEntry()

            zip.putNextEntry(ZipEntry(CSV_NAME))
            zip.write(csvText(transactions).toByteArray(Charsets.UTF_8))
            zip.closeEntry()

            val manifest = JSONObject()
                .put("formatVersion", BACKUP_FORMAT_VERSION)
                .put("createdAt", Instant.now().toString())
                .put("transactionCount", transactions.size)
                .put("receiptCount", receipts.size)
                .put("containsStartingBalance", openingBalance != null)
                .put("containsCategorySettings", true)
            zip.putNextEntry(ZipEntry(MANIFEST_NAME))
            zip.write(manifest.toString(2).toByteArray(Charsets.UTF_8))
            zip.closeEntry()

            receipts.forEach { receipt ->
                zip.putNextEntry(ZipEntry("receipts/${receipt.name}"))
                receipt.inputStream().use { it.copyTo(zip) }
                zip.closeEntry()
            }
        }
    }

    private fun validateFile(file: File, requireManifest: Boolean) {
        if (!file.exists() || file.length() == 0L) error("Backup file is empty")
        ZipFile(file).use { zip ->
            val transactionEntry = zip.getEntry(JSON_NAME) ?: error("Backup is missing transactions")
            val transactionText = zip.getInputStream(transactionEntry).bufferedReader().use { it.readText() }
            val transactions = JSONArray(transactionText)

            val settingsEntry = zip.getEntry(SETTINGS_NAME)
            if (settingsEntry != null) {
                val settingsText = zip.getInputStream(settingsEntry).bufferedReader().use { it.readText() }
                JSONObject(settingsText)
            }

            val manifestEntry = zip.getEntry(MANIFEST_NAME)
            if (requireManifest && manifestEntry == null) error("Backup verification failed: manifest missing")
            if (manifestEntry != null) {
                if (zip.getEntry(CSV_NAME) == null) error("Backup verification failed: CSV copy missing")
                val manifestText = zip.getInputStream(manifestEntry).bufferedReader().use { it.readText() }
                val manifest = JSONObject(manifestText)
                if (manifest.optInt("formatVersion", 0) < 1) error("Unsupported backup format")
                if (manifest.optInt("transactionCount", -1) != transactions.length()) {
                    error("Backup verification failed: transaction count mismatch")
                }
                val receiptEntries = zip.entries().asSequence()
                    .count { !it.isDirectory && it.name.startsWith("receipts/") }
                if (manifest.optInt("receiptCount", -1) != receiptEntries) {
                    error("Backup verification failed: receipt count mismatch")
                }
            }
        }
    }

    private fun csvText(transactions: List<MoneyTransaction>): String = buildString {
        appendLine("Date,Type,Amount GBP,Category,Description,Payment method,Customer / supplier,Job / reference,Vehicle registration,Notes,Receipt file")
        transactions.sortedWith(compareBy<MoneyTransaction> { it.date }.thenBy { it.id }).forEach { t ->
            val amount = "%.2f".format(java.util.Locale.UK, t.amountPence / 100.0)
            appendLine(
                listOf(
                    t.date.toString(),
                    t.type.name,
                    amount,
                    t.category,
                    t.description,
                    t.paymentMethod,
                    t.customerSupplier,
                    t.jobReference,
                    t.vehicleRegistration,
                    t.notes,
                    t.receiptFileName
                ).joinToString(",") { csvEscape(it) }
            )
        }
    }

    private fun csvEscape(value: String): String {
        val escaped = value.replace("\"", "\"\"")
        return if (escaped.any { it == ',' || it == '\n' || it == '\r' || it == '\"' }) "\"$escaped\"" else escaped
    }
}
