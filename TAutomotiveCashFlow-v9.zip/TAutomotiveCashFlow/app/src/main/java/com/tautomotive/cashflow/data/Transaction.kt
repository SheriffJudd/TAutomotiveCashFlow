package com.tautomotive.cashflow.data

import java.time.LocalDate

enum class TransactionType { INCOME, EXPENSE }

data class MoneyTransaction(
    val id: Long = 0,
    val type: TransactionType,
    val amountPence: Long,
    val category: String,
    val description: String,
    val date: LocalDate,
    val paymentMethod: String = "",
    val customerSupplier: String = "",
    val jobReference: String = "",
    val vehicleRegistration: String = "",
    val notes: String = "",
    val receiptFileName: String = ""
)

val defaultIncomeCategories = listOf(
    "Labour & services",
    "Parts / tyre sales",
    "Call-out",
    "Other income"
)

val defaultExpenseCategories = listOf(
    "Parts & materials",
    "Fuel",
    "Tools & equipment",
    "Vehicle costs",
    "Insurance",
    "Subcontractors",
    "Software / subscriptions",
    "Phone / internet",
    "Advertising",
    "Professional fees",
    "Bank charges",
    "Rent / storage",
    "Other expense"
)
