package com.tautomotive.cashflow.data

class CashFlowRepository(private val database: CashFlowDatabase) {
    fun getAll(): List<MoneyTransaction> = database.getAllTransactions()
    fun save(transaction: MoneyTransaction): Long = database.upsert(transaction)
    fun replaceAll(transactions: List<MoneyTransaction>) = database.replaceAll(transactions)
    fun delete(id: Long) = database.delete(id)
    fun renameCategory(type: TransactionType, oldName: String, newName: String) = database.renameCategory(type, oldName, newName)
}
