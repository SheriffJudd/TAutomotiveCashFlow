package com.tautomotive.cashflow.data

import android.content.Context
import org.json.JSONArray

data class CategorySettings(
    val incomeCategories: List<String> = defaultIncomeCategories,
    val expenseCategories: List<String> = defaultExpenseCategories,
    val archivedIncomeCategories: List<String> = emptyList(),
    val archivedExpenseCategories: List<String> = emptyList()
) {
    fun active(type: TransactionType): List<String> =
        if (type == TransactionType.INCOME) incomeCategories else expenseCategories

    fun archived(type: TransactionType): List<String> =
        if (type == TransactionType.INCOME) archivedIncomeCategories else archivedExpenseCategories
}

object CategoryStore {
    private const val PREFS = "cashflow_category_settings"
    private const val KEY_INCOME = "income_categories"
    private const val KEY_EXPENSE = "expense_categories"
    private const val KEY_ARCHIVED_INCOME = "archived_income_categories"
    private const val KEY_ARCHIVED_EXPENSE = "archived_expense_categories"

    fun load(context: Context): CategorySettings {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return CategorySettings(
            incomeCategories = readList(prefs.getString(KEY_INCOME, null)) ?: defaultIncomeCategories,
            expenseCategories = readList(prefs.getString(KEY_EXPENSE, null)) ?: defaultExpenseCategories,
            archivedIncomeCategories = readList(prefs.getString(KEY_ARCHIVED_INCOME, null)) ?: emptyList(),
            archivedExpenseCategories = readList(prefs.getString(KEY_ARCHIVED_EXPENSE, null)) ?: emptyList()
        ).sanitised()
    }

    fun save(context: Context, settings: CategorySettings) {
        val clean = settings.sanitised()
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_INCOME, JSONArray(clean.incomeCategories).toString())
            .putString(KEY_EXPENSE, JSONArray(clean.expenseCategories).toString())
            .putString(KEY_ARCHIVED_INCOME, JSONArray(clean.archivedIncomeCategories).toString())
            .putString(KEY_ARCHIVED_EXPENSE, JSONArray(clean.archivedExpenseCategories).toString())
            .apply()
    }

    fun reset(context: Context): CategorySettings {
        val settings = CategorySettings()
        save(context, settings)
        return settings
    }

    private fun readList(value: String?): List<String>? {
        if (value.isNullOrBlank()) return null
        return runCatching {
            val array = JSONArray(value)
            buildList {
                for (i in 0 until array.length()) add(array.getString(i))
            }
        }.getOrNull()
    }

    private fun CategorySettings.sanitised(): CategorySettings {
        fun clean(values: List<String>): List<String> = values
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .distinctBy { it.lowercase() }

        val income = clean(incomeCategories).ifEmpty { defaultIncomeCategories }
        val expense = clean(expenseCategories).ifEmpty { defaultExpenseCategories }
        return copy(
            incomeCategories = income,
            expenseCategories = expense,
            archivedIncomeCategories = clean(archivedIncomeCategories).filterNot { a -> income.any { it.equals(a, true) } },
            archivedExpenseCategories = clean(archivedExpenseCategories).filterNot { a -> expense.any { it.equals(a, true) } }
        )
    }
}
