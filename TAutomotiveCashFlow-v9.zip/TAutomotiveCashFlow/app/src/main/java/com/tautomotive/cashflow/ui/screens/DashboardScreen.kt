package com.tautomotive.cashflow.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.ArrowDownward
import androidx.compose.material.icons.outlined.ArrowUpward
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tautomotive.cashflow.data.MoneyTransaction
import com.tautomotive.cashflow.data.OpeningBalance
import com.tautomotive.cashflow.data.TransactionType
import com.tautomotive.cashflow.ui.components.TransactionRow
import com.tautomotive.cashflow.ui.components.currentTaxYearStartYear
import com.tautomotive.cashflow.ui.components.formatMoney
import com.tautomotive.cashflow.ui.components.formatShortDate
import com.tautomotive.cashflow.ui.components.isWithin
import com.tautomotive.cashflow.ui.components.taxYearLabel
import com.tautomotive.cashflow.ui.components.taxYearRange
import com.tautomotive.cashflow.ui.theme.AppCharcoal
import com.tautomotive.cashflow.ui.theme.ExpenseRed
import com.tautomotive.cashflow.ui.theme.IncomeGreen
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.TextStyle
import java.util.Locale
import kotlin.math.max

@Composable
fun DashboardScreen(
    transactions: List<MoneyTransaction>,
    openingBalance: OpeningBalance?,
    onAddIncome: () -> Unit,
    onAddExpense: () -> Unit,
    onEdit: (Long) -> Unit
) {
    val month = YearMonth.now()
    val monthTransactions = transactions.filter { YearMonth.from(it.date) == month }
    val income = monthTransactions.filter { it.type == TransactionType.INCOME }.sumOf { it.amountPence }
    val expenses = monthTransactions.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amountPence }
    val profit = income - expenses
    val recordedMovement = openingBalance?.let { opening ->
        transactions.filter { !it.date.isBefore(opening.date) }.sumOf {
            if (it.type == TransactionType.INCOME) it.amountPence else -it.amountPence
        }
    }
    val bankBalance = openingBalance?.let { it.amountPence + (recordedMovement ?: 0L) }
    val today = LocalDate.now()
    val taxStartYear = currentTaxYearStartYear(today)
    val taxRange = taxYearRange(taxStartYear, today)
    val taxTransactions = transactions.filter { it.date.isWithin(taxRange) }
    val taxIncome = taxTransactions.filter { it.type == TransactionType.INCOME }.sumOf { it.amountPence }
    val taxExpenses = taxTransactions.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amountPence }
    val taxNet = taxIncome - taxExpenses

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    "Cash flow",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(
                        Icons.Outlined.CalendarMonth,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        "${month.month.getDisplayName(TextStyle.FULL, Locale.UK)} ${month.year}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.primaryContainer
            ) {
                Text(
                    "T Automotive",
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
            shape = RoundedCornerShape(22.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(
                    "Current tracked balance",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                if (bankBalance != null && openingBalance != null) {
                    Text(
                        formatMoney(bankBalance),
                        style = MaterialTheme.typography.displaySmall,
                        fontWeight = FontWeight.Bold,
                        color = if (bankBalance >= 0) IncomeGreen else ExpenseRed
                    )
                    Text(
                        "Starting balance ${formatMoney(openingBalance.amountPence)} on ${formatShortDate(openingBalance.date)}",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        "Changes only from income and expenses recorded from your start date.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.labelSmall
                    )
                } else {
                    Text(
                        "Not set",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "Set a starting balance in Settings to track your running bank position.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = AppCharcoal),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(modifier = Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Net this month", color = Color(0xFFC9D5D0), style = MaterialTheme.typography.labelLarge)
                Text(
                    formatMoney(profit),
                    style = MaterialTheme.typography.displaySmall,
                    fontWeight = FontWeight.Bold,
                    color = if (profit >= 0) Color(0xFF77E0AF) else Color(0xFFFF9B9B)
                )

                Spacer(Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    HeroMetric(
                        label = "Money in",
                        value = income,
                        iconIncome = true,
                        modifier = Modifier.weight(1f)
                    )
                    HeroMetric(
                        label = "Money out",
                        value = expenses,
                        iconIncome = false,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = onAddIncome,
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = IncomeGreen),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(Icons.Outlined.Add, contentDescription = null)
                Text("  Income", fontWeight = FontWeight.SemiBold)
            }
            OutlinedButton(
                onClick = onAddExpense,
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = ExpenseRed),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(Icons.Outlined.Add, contentDescription = null)
                Text("  Expense", fontWeight = FontWeight.SemiBold)
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Tax year to date", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(
                            "${taxYearLabel(taxStartYear)} • ${formatShortDate(taxRange.start)} – ${formatShortDate(taxRange.end)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(
                        formatMoney(taxNet),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = if (taxNet > 0) IncomeGreen else if (taxNet < 0) ExpenseRed else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("In ${formatMoney(taxIncome)}", color = IncomeGreen, style = MaterialTheme.typography.bodyMedium)
                    Text("Out ${formatMoney(taxExpenses)}", color = ExpenseRed, style = MaterialTheme.typography.bodyMedium)
                }
                Text(
                    "Recorded entries only",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (openingBalance != null && openingBalance.date.isAfter(taxRange.start)) {
                    Text(
                        "Tracking start: ${formatShortDate(openingBalance.date)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("6 month overview", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(
                "Income vs expenses",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(20.dp)
            ) {
                SixMonthChart(transactions, modifier = Modifier.padding(16.dp))
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Recent activity", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            if (transactions.isEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text("Nothing recorded yet", fontWeight = FontWeight.SemiBold)
                        Text(
                            "Use Income or Expense above to add your first entry.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp)) {
                        transactions.take(5).forEach { transaction ->
                            TransactionRow(
                                transaction = transaction,
                                onClick = { onEdit(transaction.id) },
                                onDelete = {},
                                showDelete = false
                            )
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(70.dp))
    }
}

@Composable
private fun HeroMetric(
    label: String,
    value: Long,
    iconIncome: Boolean,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .background(Color(0xFF24332E), RoundedCornerShape(16.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        Box(
            modifier = Modifier
                .size(34.dp)
                .background(
                    if (iconIncome) Color(0xFF185C43) else Color(0xFF663536),
                    RoundedCornerShape(11.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                if (iconIncome) Icons.Outlined.ArrowDownward else Icons.Outlined.ArrowUpward,
                contentDescription = null,
                tint = if (iconIncome) Color(0xFF80E4B6) else Color(0xFFFFA1A1),
                modifier = Modifier.size(18.dp)
            )
        }
        Column {
            Text(label, color = Color(0xFFB8C8C1), style = MaterialTheme.typography.labelSmall)
            Text(formatMoney(value), color = Color.White, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SixMonthChart(transactions: List<MoneyTransaction>, modifier: Modifier = Modifier) {
    val current = YearMonth.now()
    val months = (5 downTo 0).map { current.minusMonths(it.toLong()) }
    val totals = months.map { month ->
        val items = transactions.filter { YearMonth.from(it.date) == month }
        val inTotal = items.filter { it.type == TransactionType.INCOME }.sumOf { it.amountPence }
        val outTotal = items.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amountPence }
        Triple(month, inTotal, outTotal)
    }
    val maxValue = max(1L, totals.maxOfOrNull { max(it.second, it.third) } ?: 1L)

    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
            LegendDot(IncomeGreen, "Income")
            LegendDot(ExpenseRed, "Expenses")
        }
        Row(
            modifier = Modifier.fillMaxWidth().height(126.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.Bottom
        ) {
            totals.forEach { (month, inTotal, outTotal) ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(
                        modifier = Modifier.height(92.dp),
                        verticalAlignment = Alignment.Bottom,
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        val inHeight = if (inTotal == 0L) 3.dp else (84f * inTotal / maxValue).dp
                        val outHeight = if (outTotal == 0L) 3.dp else (84f * outTotal / maxValue).dp
                        Box(
                            Modifier
                                .width(9.dp)
                                .height(inHeight)
                                .background(IncomeGreen, RoundedCornerShape(topStart = 5.dp, topEnd = 5.dp))
                        )
                        Box(
                            Modifier
                                .width(9.dp)
                                .height(outHeight)
                                .background(ExpenseRed, RoundedCornerShape(topStart = 5.dp, topEnd = 5.dp))
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        month.month.getDisplayName(TextStyle.SHORT, Locale.UK).take(3),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun LegendDot(color: Color, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Box(Modifier.size(8.dp).background(color, RoundedCornerShape(50)))
        Text(text, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
