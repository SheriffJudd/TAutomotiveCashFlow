package com.tautomotive.cashflow.ui.screens

import android.app.DatePickerDialog
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountBalance
import androidx.compose.material.icons.outlined.Backup
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.PictureAsPdf
import androidx.compose.material.icons.outlined.Restore
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.tautomotive.cashflow.data.CategorySettings
import com.tautomotive.cashflow.data.MoneyTransaction
import com.tautomotive.cashflow.data.TransactionType
import com.tautomotive.cashflow.data.OpeningBalance
import com.tautomotive.cashflow.data.PdfReportSpec
import com.tautomotive.cashflow.ui.BackupSafetyState
import com.tautomotive.cashflow.ui.components.CategorySettingsCard
import com.tautomotive.cashflow.ui.components.ReportDateRange
import com.tautomotive.cashflow.ui.components.currentTaxYearStartYear
import com.tautomotive.cashflow.ui.components.formatDate
import com.tautomotive.cashflow.ui.components.formatMoney
import com.tautomotive.cashflow.ui.components.formatShortDate
import com.tautomotive.cashflow.ui.components.taxYearLabel
import com.tautomotive.cashflow.ui.components.taxYearRange
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.LocalDate
import java.time.YearMonth

private enum class PdfPeriod { TAX_YEAR, THIS_MONTH, ALL_RECORDS, CUSTOM }

@Composable
fun SettingsScreen(
    transactions: List<MoneyTransaction>,
    openingBalance: OpeningBalance?,
    categorySettings: CategorySettings,
    backupSafety: BackupSafetyState,
    onSetOpeningBalance: (OpeningBalance) -> Unit,
    onClearOpeningBalance: () -> Unit,
    onAddCategory: (TransactionType, String) -> Unit,
    onRenameCategory: (TransactionType, String, String) -> Unit,
    onArchiveCategory: (TransactionType, String) -> Unit,
    onRestoreCategory: (TransactionType, String) -> Unit,
    onResetCategories: () -> Unit,
    onExport: (Uri, (Result<Unit>) -> Unit) -> Unit,
    onExportCsv: (Uri, (Result<Unit>) -> Unit) -> Unit,
    onExportPdf: (Uri, PdfReportSpec, (Result<Unit>) -> Unit) -> Unit,
    onSharePdf: (PdfReportSpec, (Result<Uri>) -> Unit) -> Unit,
    onImport: (Uri, (Result<Int>) -> Unit) -> Unit,
    onConfigureAutoBackup: (Uri, (Result<Unit>) -> Unit) -> Unit,
    onDisableAutoBackup: () -> Unit,
    onRunAutoBackup: ((Result<Unit>) -> Unit) -> Unit
) {
    val context = LocalContext.current
    val today = LocalDate.now()
    val taxStartYear = currentTaxYearStartYear(today)

    var status by remember { mutableStateOf<String?>(null) }
    var pendingRestore by remember { mutableStateOf<Uri?>(null) }
    var showOpeningBalanceDialog by remember { mutableStateOf(false) }
    var confirmClearOpeningBalance by remember { mutableStateOf(false) }
    var confirmDisableAutoBackup by remember { mutableStateOf(false) }

    var pdfPeriod by remember { mutableStateOf(PdfPeriod.TAX_YEAR) }
    var pdfCustomStart by remember { mutableStateOf(LocalDate.of(taxStartYear, 4, 6)) }
    var pdfCustomEnd by remember { mutableStateOf(today) }
    var includeReceiptImages by remember { mutableStateOf(false) }
    var pendingPdfSpec by remember { mutableStateOf<PdfReportSpec?>(null) }

    val earliestTransaction = transactions.minOfOrNull { it.date }
    val latestTransaction = transactions.maxOfOrNull { it.date }
    val allStart = listOfNotNull(openingBalance?.date, earliestTransaction).minOrNull() ?: today
    val allEnd = maxOf(today, latestTransaction ?: today)
    val month = YearMonth.from(today)

    val pdfRange: ReportDateRange = when (pdfPeriod) {
        PdfPeriod.TAX_YEAR -> taxYearRange(taxStartYear, today)
        PdfPeriod.THIS_MONTH -> ReportDateRange(month.atDay(1), today)
        PdfPeriod.ALL_RECORDS -> ReportDateRange(allStart, allEnd)
        PdfPeriod.CUSTOM -> ReportDateRange(pdfCustomStart, pdfCustomEnd)
    }
    val pdfLabel = when (pdfPeriod) {
        PdfPeriod.TAX_YEAR -> "Tax year ${taxYearLabel(taxStartYear)}"
        PdfPeriod.THIS_MONTH -> "This month"
        PdfPeriod.ALL_RECORDS -> "All records"
        PdfPeriod.CUSTOM -> "Custom period"
    }
    val currentPdfSpec = PdfReportSpec(
        startDate = pdfRange.start,
        endDate = pdfRange.end,
        periodLabel = pdfLabel,
        includeReceiptImages = includeReceiptImages
    )

    val createBackup = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        if (uri != null) {
            status = "Creating and verifying backup…"
            onExport(uri) { result ->
                status = if (result.isSuccess) {
                    "Backup saved and verified successfully."
                } else {
                    "Backup failed: ${result.exceptionOrNull()?.message ?: "Unknown error"}"
                }
            }
        }
    }

    val createCsv = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        if (uri != null) {
            status = "Exporting CSV…"
            onExportCsv(uri) { result ->
                status = if (result.isSuccess) {
                    "CSV exported successfully."
                } else {
                    "CSV export failed: ${result.exceptionOrNull()?.message ?: "Unknown error"}"
                }
            }
        }
    }

    val createPdf = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        val spec = pendingPdfSpec
        pendingPdfSpec = null
        if (uri != null && spec != null) {
            status = "Creating PDF report…"
            onExportPdf(uri, spec) { result ->
                status = if (result.isSuccess) {
                    "PDF report saved successfully."
                } else {
                    "PDF report failed: ${result.exceptionOrNull()?.message ?: "Unknown error"}"
                }
            }
        }
    }

    val openBackup = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) pendingRestore = uri
    }

    val chooseAutoBackupFolder = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            status = "Setting up automatic backups and creating the first verified backup…"
            onConfigureAutoBackup(uri) { result ->
                status = if (result.isSuccess) {
                    "Automatic backups are on. First backup created and verified."
                } else {
                    "Could not enable automatic backups: ${result.exceptionOrNull()?.message ?: "Unknown error"}"
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Outlined.AccountBalance, contentDescription = null)
                    Text("Starting balance", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                }

                if (openingBalance == null) {
                    Text(
                        "Set the exact bank balance at the point you start tracking for real. This fixed starting point is kept separate from income, expenses and P&L.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Button(
                        onClick = { showOpeningBalanceDialog = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Outlined.AccountBalance, contentDescription = null)
                        Text("  Set starting balance")
                    }
                } else {
                    Text(
                        formatMoney(openingBalance.amountPence),
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "Fixed at ${formatDate(openingBalance.date)} • excluded from P&L",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedButton(
                        onClick = { showOpeningBalanceDialog = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Outlined.Edit, contentDescription = null)
                        Text("  Change starting balance")
                    }
                    TextButton(
                        onClick = { confirmClearOpeningBalance = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Remove starting balance")
                    }
                }
            }
        }

        CategorySettingsCard(
            settings = categorySettings,
            onAdd = onAddCategory,
            onRename = onRenameCategory,
            onArchive = onArchiveCategory,
            onRestore = onRestoreCategory,
            onReset = onResetCategories
        )

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Outlined.Folder, contentDescription = null)
                    Text("Automatic safety backups", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                }

                if (!backupSafety.enabled) {
                    Text(
                        "Off. Choose a folder and the app will create a verified ZIP backup after every data change. It also checks on app launch and keeps the latest 10 backups.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Button(
                        onClick = { chooseAutoBackupFolder.launch(null) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Outlined.Backup, contentDescription = null)
                        Text("  Choose backup folder")
                    }
                } else {
                    Text("On", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Text(
                        "Folder: ${backupSafety.folderName}",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        "Last verified backup: ${backupSafety.lastBackupText ?: "Not yet completed"}",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    backupSafety.lastError?.let { error ->
                        Text("Last backup problem: $error", color = MaterialTheme.colorScheme.error)
                    }
                    Text(
                        "Each backup contains transactions, starting balance, category settings, receipt photos and a CSV copy. The app verifies the ZIP after writing it and keeps the newest 10 automatic backups.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Button(
                        onClick = {
                            status = "Creating and verifying automatic backup…"
                            onRunAutoBackup { result ->
                                status = if (result.isSuccess) {
                                    "Automatic backup created and verified."
                                } else {
                                    "Backup failed: ${result.exceptionOrNull()?.message ?: "Unknown error"}"
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Outlined.Backup, contentDescription = null)
                        Text("  Back up now")
                    }
                    OutlinedButton(
                        onClick = { chooseAutoBackupFolder.launch(null) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Change backup folder")
                    }
                    TextButton(
                        onClick = { confirmDisableAutoBackup = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Turn off automatic backups")
                    }
                }
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.PictureAsPdf, contentDescription = null)
                    Text("PDF reports", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                }
                Text(
                    "Create a readable report to keep or share with a family member. Reports use only the figures you have actually recorded.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = pdfPeriod == PdfPeriod.TAX_YEAR,
                        onClick = { pdfPeriod = PdfPeriod.TAX_YEAR },
                        label = { Text("Tax year") }
                    )
                    FilterChip(
                        selected = pdfPeriod == PdfPeriod.THIS_MONTH,
                        onClick = { pdfPeriod = PdfPeriod.THIS_MONTH },
                        label = { Text("This month") }
                    )
                    FilterChip(
                        selected = pdfPeriod == PdfPeriod.ALL_RECORDS,
                        onClick = { pdfPeriod = PdfPeriod.ALL_RECORDS },
                        label = { Text("All records") }
                    )
                    FilterChip(
                        selected = pdfPeriod == PdfPeriod.CUSTOM,
                        onClick = { pdfPeriod = PdfPeriod.CUSTOM },
                        label = { Text("Custom") }
                    )
                }

                Text(
                    "$pdfLabel • ${formatShortDate(pdfRange.start)} – ${formatShortDate(pdfRange.end)}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold
                )

                if (pdfPeriod == PdfPeriod.CUSTOM) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                DatePickerDialog(
                                    context,
                                    { _, year, monthValue, day ->
                                        val picked = LocalDate.of(year, monthValue + 1, day)
                                        pdfCustomStart = picked
                                        if (pdfCustomEnd.isBefore(picked)) pdfCustomEnd = picked
                                    },
                                    pdfCustomStart.year,
                                    pdfCustomStart.monthValue - 1,
                                    pdfCustomStart.dayOfMonth
                                ).show()
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text("From") }
                        OutlinedButton(
                            onClick = {
                                DatePickerDialog(
                                    context,
                                    { _, year, monthValue, day ->
                                        val picked = LocalDate.of(year, monthValue + 1, day)
                                        pdfCustomEnd = picked
                                        if (pdfCustomStart.isAfter(picked)) pdfCustomStart = picked
                                    },
                                    pdfCustomEnd.year,
                                    pdfCustomEnd.monthValue - 1,
                                    pdfCustomEnd.dayOfMonth
                                ).show()
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text("To") }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = includeReceiptImages,
                        onCheckedChange = { includeReceiptImages = it }
                    )
                    Column {
                        Text("Include receipt images")
                        Text(
                            "Off by default to keep the PDF small. Receipt attachment status is listed either way.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Button(
                    onClick = {
                        val spec = currentPdfSpec
                        pendingPdfSpec = spec
                        val safe = spec.periodLabel.replace(Regex("[^A-Za-z0-9]+"), "_").trim('_')
                        createPdf.launch("TAutomotive_CashFlow_${safe}_${today}.pdf")
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Outlined.PictureAsPdf, contentDescription = null)
                    Text("  Save PDF report")
                }

                OutlinedButton(
                    onClick = {
                        status = "Creating PDF to share…"
                        onSharePdf(currentPdfSpec) { result ->
                            result.fold(
                                onSuccess = { uri ->
                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "application/pdf"
                                        putExtra(Intent.EXTRA_STREAM, uri)
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        putExtra(Intent.EXTRA_SUBJECT, "T Automotive cash flow report — $pdfLabel")
                                    }
                                    context.startActivity(Intent.createChooser(shareIntent, "Share cash flow report"))
                                    status = "PDF created and ready to share."
                                },
                                onFailure = { error ->
                                    status = "Could not create PDF: ${error.message ?: "Unknown error"}"
                                }
                            )
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Outlined.Share, contentDescription = null)
                    Text("  Share PDF")
                }

                Text(
                    "The report includes totals, category breakdowns, detailed transactions, customer/supplier, vehicle registration, job reference, payment method and receipt status. Starting balance stays separate from P&L.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Manual backup & export", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(
                    "ZIP backups include all transactions, category settings, receipt photos, your starting balance and a CSV copy. Manual ZIP backups are verified after they are saved.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Button(
                    onClick = { createBackup.launch("TAutomotive_Backup_${LocalDate.now()}.zip") },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Outlined.Backup, contentDescription = null)
                    Text("  Save manual ZIP backup")
                }

                OutlinedButton(
                    onClick = { createCsv.launch("TAutomotive_Transactions_${LocalDate.now()}.csv") },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Export transactions as CSV")
                }

                OutlinedButton(
                    onClick = { openBackup.launch(arrayOf("application/zip", "application/octet-stream")) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Outlined.Restore, contentDescription = null)
                    Text("  Restore backup")
                }
            }
        }

        status?.let { Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }

    if (showOpeningBalanceDialog) {
        OpeningBalanceDialog(
            existing = openingBalance,
            onDismiss = { showOpeningBalanceDialog = false },
            onSave = {
                onSetOpeningBalance(it)
                showOpeningBalanceDialog = false
                status = "Starting balance saved. Automatic backup will include the change if enabled."
            }
        )
    }

    if (confirmClearOpeningBalance) {
        AlertDialog(
            onDismissRequest = { confirmClearOpeningBalance = false },
            title = { Text("Remove starting balance?") },
            text = { Text("Your transactions will stay untouched. The app will simply stop calculating a bank balance from a starting amount.") },
            confirmButton = {
                TextButton(onClick = {
                    onClearOpeningBalance()
                    confirmClearOpeningBalance = false
                    status = "Starting balance removed."
                }) { Text("Remove") }
            },
            dismissButton = { TextButton(onClick = { confirmClearOpeningBalance = false }) { Text("Cancel") } }
        )
    }

    if (confirmDisableAutoBackup) {
        AlertDialog(
            onDismissRequest = { confirmDisableAutoBackup = false },
            title = { Text("Turn off automatic backups?") },
            text = { Text("Existing backup files will stay in your chosen folder. The app will stop creating new automatic backups.") },
            confirmButton = {
                TextButton(onClick = {
                    onDisableAutoBackup()
                    confirmDisableAutoBackup = false
                    status = "Automatic backups turned off."
                }) { Text("Turn off") }
            },
            dismissButton = { TextButton(onClick = { confirmDisableAutoBackup = false }) { Text("Cancel") } }
        )
    }

    pendingRestore?.let { uri ->
        AlertDialog(
            onDismissRequest = { pendingRestore = null },
            title = { Text("Restore backup?") },
            text = { Text("The backup is checked before restore. If valid, it will replace the transactions, starting balance and saved category settings contained in that backup.") },
            confirmButton = {
                TextButton(onClick = {
                    pendingRestore = null
                    status = "Checking and restoring backup…"
                    onImport(uri) { result ->
                        status = result.fold(
                            onSuccess = { count -> "Restore complete: $count transactions restored." },
                            onFailure = { error -> "Restore failed: ${error.message ?: "Unknown error"}" }
                        )
                    }
                }) { Text("Restore") }
            },
            dismissButton = { TextButton(onClick = { pendingRestore = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun OpeningBalanceDialog(
    existing: OpeningBalance?,
    onDismiss: () -> Unit,
    onSave: (OpeningBalance) -> Unit
) {
    val context = LocalContext.current
    var amountText by remember(existing) {
        mutableStateOf(
            existing?.let { BigDecimal(it.amountPence).divide(BigDecimal(100)).toPlainString() } ?: ""
        )
    }
    var date by remember(existing) { mutableStateOf(existing?.date ?: LocalDate.now()) }
    var validationError by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Set starting balance" else "Change starting balance") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Enter the exact amount shown in your bank account when you start tracking. You can type any amount, including pence or a negative overdraft balance.")
                OutlinedTextField(
                    value = amountText,
                    onValueChange = {
                        amountText = it
                        validationError = null
                    },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Starting bank balance (£)") },
                    placeholder = { Text("6000.00") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    supportingText = { validationError?.let { Text(it) } },
                    isError = validationError != null
                )
                OutlinedButton(
                    onClick = {
                        DatePickerDialog(
                            context,
                            { _, year, month, day -> date = LocalDate.of(year, month + 1, day) },
                            date.year,
                            date.monthValue - 1,
                            date.dayOfMonth
                        ).apply { datePicker.maxDate = System.currentTimeMillis() }.show()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Start date: ${formatDate(date)}")
                }
                Text(
                    "This fixed amount is not treated as income and never appears in Profit & Loss. Your tracked balance changes separately as you record transactions.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val cleaned = amountText.trim().replace(",", "")
                val parsed = cleaned.toBigDecimalOrNull()
                if (parsed == null) {
                    validationError = "Enter a valid amount, for example 6000.00"
                    return@TextButton
                }
                val pence = runCatching {
                    parsed.multiply(BigDecimal(100)).setScale(0, RoundingMode.HALF_UP).longValueExact()
                }.getOrNull()
                if (pence == null) {
                    validationError = "Amount is too large"
                    return@TextButton
                }
                onSave(OpeningBalance(amountPence = pence, date = date))
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
