package com.tautomotive.cashflow.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val IncomeGreen = Color(0xFF12855C)
val IncomeGreenDark = Color(0xFF55D49A)
val ExpenseRed = Color(0xFFD04444)
val ExpenseRedDark = Color(0xFFFF8D8D)
val AppCharcoal = Color(0xFF17231F)
val AppCharcoalLight = Color(0xFF24342E)
val SoftGreen = Color(0xFFE4F4ED)
val SoftRed = Color(0xFFFBE8E8)
val WarmSurface = Color(0xFFF7F9F8)

private val LightColors = lightColorScheme(
    primary = IncomeGreen,
    onPrimary = Color.White,
    primaryContainer = SoftGreen,
    onPrimaryContainer = Color(0xFF063D2A),
    secondary = Color(0xFF386B6B),
    secondaryContainer = Color(0xFFDCEBEC),
    error = ExpenseRed,
    errorContainer = SoftRed,
    background = WarmSurface,
    surface = Color.White,
    surfaceVariant = Color(0xFFE8EEEB),
    surfaceContainerLow = Color(0xFFF0F4F2),
    surfaceContainer = Color(0xFFEBF0ED),
    surfaceContainerHigh = Color(0xFFE4EAE7),
    onSurface = AppCharcoal,
    onSurfaceVariant = Color(0xFF5E6B66),
    outline = Color(0xFFBBC7C1)
)

private val DarkColors = darkColorScheme(
    primary = IncomeGreenDark,
    onPrimary = Color(0xFF003824),
    primaryContainer = Color(0xFF0E5039),
    secondary = Color(0xFF9CCFCF),
    error = ExpenseRedDark,
    errorContainer = Color(0xFF642B2B),
    background = Color(0xFF0F1513),
    surface = Color(0xFF151D1A),
    surfaceVariant = Color(0xFF26312D),
    onSurface = Color(0xFFE8EFEC),
    onSurfaceVariant = Color(0xFFB7C5BF)
)

@Composable
fun CashFlowTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        content = content
    )
}
