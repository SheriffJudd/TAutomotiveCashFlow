package com.tautomotive.cashflow.data

import android.content.Context
import java.time.LocalDate

data class OpeningBalance(
    val amountPence: Long,
    val date: LocalDate
)

object OpeningBalanceStore {
    private const val PREFS = "cashflow_settings"
    private const val KEY_AMOUNT = "opening_balance_pence"
    private const val KEY_DATE = "opening_balance_date"

    fun load(context: Context): OpeningBalance? {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!prefs.contains(KEY_AMOUNT) || !prefs.contains(KEY_DATE)) return null
        val dateText = prefs.getString(KEY_DATE, null) ?: return null
        return runCatching {
            OpeningBalance(
                amountPence = prefs.getLong(KEY_AMOUNT, 0L),
                date = LocalDate.parse(dateText)
            )
        }.getOrNull()
    }

    fun save(context: Context, openingBalance: OpeningBalance) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putLong(KEY_AMOUNT, openingBalance.amountPence)
            .putString(KEY_DATE, openingBalance.date.toString())
            .apply()
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .remove(KEY_AMOUNT)
            .remove(KEY_DATE)
            .apply()
    }
}
