package com.tautomotive.cashflow.ui.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tautomotive.cashflow.data.MoneyTransaction
import com.tautomotive.cashflow.data.OpeningBalance
import com.tautomotive.cashflow.data.TransactionType
import com.tautomotive.cashflow.ui.components.ReportDateRange
import com.tautomotive.cashflow.ui.components.calendarYearRange
import com.tautomotive.cashflow.ui.components.currentTaxYearStartYear
import com.tautomotive.cashflow.ui.components.formatMoney
import com.tautomotive.cashflow.ui.components.formatShortDate
import com.tautomotive.cashflow.ui.components.isWithin
import com.tautomotive.cashflow.ui.components.taxYearLabel
import com.tautomotive.cashflow.ui.components.taxYearRange
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.TextStyle
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max

private enum class PnlPeriod { TAX_YEAR, CALENDAR_YEAR, CUSTOM }
private data class ReportBucket(val label: String, val start: LocalDate, val end: LocalDate)

@Composable
fun ProfitLossScreen(transactions: List<MoneyTransaction>, openingBalance: OpeningBalance?) {
    val today = LocalDate.now()
    val currentTaxStartYear = currentTaxYearStartYear(today)
    var period by remember { mutableStateOf(PnlPeriod.TAX_YEAR) }
    var taxStartYear by remember { mutableIntStateOf(currentTaxStartYear) }
    var calendarYear by remember { mutableIntStateOf(today.year) }
    var customStart by remember { mutableStateOf(LocalDate.of(currentTaxStartYear, 4, 6)) }
    var customEnd by remember { mutableStateOf(today) }
    val context = LocalContext.current

    val range = when (period) {
        PnlPeriod.TAX_YEAR -> taxYearRange(taxStartYear, today)
        PnlPeriod.CALENDAR_YEAR -> calendarYearRange(calendarYear, today)
        PnlPeriod.CUSTOM -> ReportDateRange(customStart, customEnd)
    }
    val selected = transactions.filter { it.date.isWithin(range) }
    val income = selected.filter { it.type == TransactionType.INCOME }.sumOf { it.amountPence }
    val expenses = selected.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amountPence }
    val profit = income - expenses
    val buckets = when (period) {
        PnlPeriod.TAX_YEAR -> taxMonthBuckets(taxStartYear, range)
        PnlPeriod.CALENDAR_YEAR -> calendarMonthBuckets(calendarYear, range)
        PnlPeriod.CUSTOM -> customMonthBuckets(range)
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Profit & Loss", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = period == PnlPeriod.TAX_YEAR,
                onClick = { period = PnlPeriod.TAX_YEAR },
                label = { Text("Tax year") }
            )
            FilterChip(
                selected = period == PnlPeriod.CALENDAR_YEAR,
                onClick = { period = PnlPeriod.CALENDAR_YEAR },
                label = { Text("Calendar year") }
            )
            FilterChip(
                selected = period == PnlPeriod.CUSTOM,
                onClick = { period = PnlPeriod.CUSTOM },
                label = { Text("Custom") }
            )
        }

        if (period != PnlPeriod.CUSTOM) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        if (period == PnlPeriod.TAX_YEAR) taxStartYear-- else calendarYear--
                    }
                ) {
                    Icon(Icons.Outlined.ChevronLeft, "Previous period")
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        if (period == PnlPeriod.TAX_YEAR) "Tax year ${taxYearLabel(taxStartYear)}" else calendarYear.toString(),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "${formatShortDate(range.start)} – ${formatShortDate(range.end)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                val canGoNext = if (period == PnlPeriod.TAX_YEAR) {
                    taxStartYear < currentTaxStartYear
                } else {
                    calendarYear < today.year
                }
                IconButton(
                    enabled = canGoNext,
                    onClick = {
                        if (period == PnlPeriod.TAX_YEAR) taxStartYear++ else calendarYear++
                    }
                ) {
                    Icon(Icons.Outlined.ChevronRight, "Next period")
                }
            }
        } else {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        DatePickerDialog(
                            context,
                            { _, y, m, d ->
                                val picked = LocalDate.of(y, m + 1, d)
                                customStart = picked
                                if (customEnd.isBefore(picked)) customEnd = picked
                            },
                            customStart.year,
                            customStart.monthValue - 1,
                            customStart.dayOfMonth
                        ).show()
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("From ${formatShortDate(customStart)}")
                }
                OutlinedButton(
                    onClick = {
                        DatePickerDialog(
                            context,
                            { _, y, m, d ->
                                val picked = LocalDate.of(y, m + 1, d)
                                customEnd = picked
                                if (customStart.isAfter(picked)) customStart = picked
                            },
                            customEnd.year,
                            customEnd.monthValue - 1,
                            customEnd.dayOfMonth
                        ).show()
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("To ${formatShortDate(customEnd)}")
                }
            }
        }

        Text(
            "Recorded entries only — no estimates or projections. Starting balance is excluded from P&L.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (openingBalance != null && openingBalance.date.isAfter(range.start)) {
            Text(
                "Tracking start: ${formatShortDate(openingBalance.date)}. Figures before this date may be incomplete unless you backfill them.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(22.dp)
        ) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("Recorded net profit", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                    formatMoney(profit),
                    style = MaterialTheme.typography.displaySmall,
                    fontWeight = FontWeight.Bold,
                    color = netColour(profit)
                )
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PnlMiniCard("Income", income, true, Modifier.weight(1f))
                    PnlMiniCard("Expenses", expenses, false, Modifier.weight(1f))
                }
            }
        }

        Text("Period performance", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        PeriodProfitChart(selected, buckets)

        Text("Breakdown", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        if (period == PnlPeriod.TAX_YEAR) {
            Text(
                "Tax-month rows run from the 6th to the 5th, matching the UK tax year.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
            Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
                Row(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                    Text("Period", modifier = Modifier.weight(0.9f), fontWeight = FontWeight.Bold)
                    Text("In", modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
                    Text("Out", modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
                    Text("Net", modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
                }
                HorizontalDivider()
                buckets.forEachIndexed { index, bucket ->
                    val items = selected.filter { !it.date.isBefore(bucket.start) && !it.date.isAfter(bucket.end) }
                    val bucketIncome = items.filter { it.type == TransactionType.INCOME }.sumOf { it.amountPence }
                    val bucketExpenses = items.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amountPence }
                    val bucketProfit = bucketIncome - bucketExpenses
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(bucket.label, modifier = Modifier.weight(0.9f))
                        Text(
                            formatMoney(bucketIncome),
                            modifier = Modifier.weight(1f),
                            style = MaterialTheme.typography.bodySmall,
                            color = if (bucketIncome > 0L) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            formatMoney(bucketExpenses),
                            modifier = Modifier.weight(1f),
                            style = MaterialTheme.typography.bodySmall,
                            color = if (bucketExpenses > 0L) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            formatMoney(bucketProfit),
                            modifier = Modifier.weight(1f),
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = netColour(bucketProfit)
                        )
                    }
                    if (index < buckets.lastIndex) HorizontalDivider()
                }
            }
        }

        Text("Expense categories", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        val categories = selected
            .filter { it.type == TransactionType.EXPENSE }
            .groupBy { it.category }
            .mapValues { (_, values) -> values.sumOf { it.amountPence } }
            .toList()
            .sortedByDescending { it.second }

        if (categories.isEmpty()) {
            Text("No expenses recorded in this period.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            val maxCategory = max(1L, categories.maxOf { it.second })
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    categories.forEach { (category, total) ->
                        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(category, style = MaterialTheme.typography.bodyMedium)
                                Text(formatMoney(total), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                            }
                            Box(
                                Modifier
                                    .fillMaxWidth()
                                    .height(7.dp)
                                    .background(MaterialTheme.colorScheme.surfaceContainerHigh, RoundedCornerShape(50))
                            ) {
                                Box(
                                    Modifier
                                        .fillMaxWidth(total.toFloat() / maxCategory.toFloat())
                                        .height(7.dp)
                                        .background(MaterialTheme.colorScheme.error, RoundedCornerShape(50))
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PnlMiniCard(label: String, amount: Long, income: Boolean, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = if (income) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                formatMoney(amount),
                fontWeight = FontWeight.Bold,
                color = if (income) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
            )
        }
    }
}

@Composable
private fun netColour(amount: Long): Color = when {
    amount > 0L -> MaterialTheme.colorScheme.primary
    amount < 0L -> MaterialTheme.colorScheme.error
    else -> MaterialTheme.colorScheme.onSurfaceVariant
}

@Composable
private fun PeriodProfitChart(transactions: List<MoneyTransaction>, buckets: List<ReportBucket>) {
    val chartBuckets = buckets.takeLast(12)
    val values = chartBuckets.map { bucket ->
        val items = transactions.filter { !it.date.isBefore(bucket.start) && !it.date.isAfter(bucket.end) }
        val income = items.filter { it.type == TransactionType.INCOME }.sumOf { it.amountPence }
        val expenses = items.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amountPence }
        bucket to (income - expenses)
    }
    val maxAbs = max(1L, values.maxOfOrNull { abs(it.second) } ?: 1L)

    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
        if (values.isEmpty()) {
            Text("No periods to display.", modifier = Modifier.padding(18.dp))
        } else {
            Row(
                modifier = Modifier.fillMaxWidth().height(140.dp).padding(horizontal = 12.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.Bottom
            ) {
                values.forEach { (bucket, value) ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        val barHeight = if (value == 0L) 3.dp else (82f * abs(value).toFloat() / maxAbs.toFloat()).dp
                        Box(
                            Modifier
                                .width(10.dp)
                                .height(barHeight)
                                .background(
                                    if (value >= 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                                    RoundedCornerShape(topStart = 5.dp, topEnd = 5.dp)
                                )
                        )
                        Text(
                            bucket.label.take(3),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(top = 5.dp)
                        )
                    }
                }
            }
        }
    }
}

private fun taxMonthBuckets(startYear: Int, range: ReportDateRange): List<ReportBucket> =
    (0L until 12L).mapNotNull { offset ->
        val start = LocalDate.of(startYear, 4, 6).plusMonths(offset)
        if (start.isAfter(range.end)) return@mapNotNull null
        val end = minDate(start.plusMonths(1).minusDays(1), range.end)
        val label = start.month.getDisplayName(TextStyle.SHORT, Locale.UK)
        ReportBucket(label, start, end)
    }

private fun calendarMonthBuckets(year: Int, range: ReportDateRange): List<ReportBucket> =
    (1..12).mapNotNull { month ->
        val ym = YearMonth.of(year, month)
        val start = ym.atDay(1)
        if (start.isAfter(range.end)) return@mapNotNull null
        val end = minDate(ym.atEndOfMonth(), range.end)
        ReportBucket(ym.month.getDisplayName(TextStyle.SHORT, Locale.UK), start, end)
    }

private fun customMonthBuckets(range: ReportDateRange): List<ReportBucket> {
    val output = mutableListOf<ReportBucket>()
    var month = YearMonth.from(range.start)
    val last = YearMonth.from(range.end)
    val spansYears = range.start.year != range.end.year
    while (!month.isAfter(last)) {
        val start = maxDate(month.atDay(1), range.start)
        val end = minDate(month.atEndOfMonth(), range.end)
        val monthName = month.month.getDisplayName(TextStyle.SHORT, Locale.UK)
        val label = if (spansYears) "$monthName ${month.year.toString().takeLast(2)}" else monthName
        output += ReportBucket(label, start, end)
        month = month.plusMonths(1)
    }
    return output
}

private fun minDate(a: LocalDate, b: LocalDate): LocalDate = if (a.isBefore(b)) a else b
private fun maxDate(a: LocalDate, b: LocalDate): LocalDate = if (a.isAfter(b)) a else b
