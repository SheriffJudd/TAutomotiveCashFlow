package com.tautomotive.cashflow.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.text.NumberFormat
import kotlin.math.min


data class PdfReportSpec(
    val startDate: LocalDate,
    val endDate: LocalDate,
    val periodLabel: String,
    val includeReceiptImages: Boolean = false
)

object PdfReportManager {
    private val moneyFormat = NumberFormat.getCurrencyInstance(Locale.UK)
    private val dateFormat = DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.UK)
    private const val PAGE_WIDTH = 595
    private const val PAGE_HEIGHT = 842
    private const val MARGIN = 42f
    private const val CONTENT_WIDTH = PAGE_WIDTH - (MARGIN * 2)

    fun export(
        context: Context,
        transactions: List<MoneyTransaction>,
        openingBalance: OpeningBalance?,
        spec: PdfReportSpec,
        destination: Uri
    ) {
        val document = buildDocument(context, transactions, openingBalance, spec)
        try {
            context.contentResolver.openOutputStream(destination, "w")?.use { output ->
                document.writeTo(output)
            } ?: error("Could not open the selected PDF destination")
        } finally {
            document.close()
        }
    }

    fun createShareable(
        context: Context,
        transactions: List<MoneyTransaction>,
        openingBalance: OpeningBalance?,
        spec: PdfReportSpec
    ): Uri {
        val reportsDir = File(context.cacheDir, "reports").apply { mkdirs() }
        reportsDir.listFiles()?.forEach { file ->
            if (file.isFile && System.currentTimeMillis() - file.lastModified() > 24L * 60L * 60L * 1000L) {
                file.delete()
            }
        }
        val safeLabel = spec.periodLabel.replace(Regex("[^A-Za-z0-9_-]+"), "_").trim('_').ifBlank { "Report" }
        val file = File(reportsDir, "TAutomotive_CashFlow_${safeLabel}_${LocalDate.now()}.pdf")
        val document = buildDocument(context, transactions, openingBalance, spec)
        try {
            file.outputStream().use { output -> document.writeTo(output) }
        } finally {
            document.close()
        }
        return FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
    }

    private fun buildDocument(
        context: Context,
        transactions: List<MoneyTransaction>,
        openingBalance: OpeningBalance?,
        spec: PdfReportSpec
    ): PdfDocument {
        require(!spec.endDate.isBefore(spec.startDate)) { "Report end date cannot be before start date" }

        val selected = transactions
            .filter { !it.date.isBefore(spec.startDate) && !it.date.isAfter(spec.endDate) }
            .sortedWith(compareBy<MoneyTransaction> { it.date }.thenBy { it.id })

        val income = selected.filter { it.type == TransactionType.INCOME }.sumOf { it.amountPence }
        val expenses = selected.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amountPence }
        val net = income - expenses
        val receiptCount = selected.count { it.receiptFileName.isNotBlank() }

        val trackedBalanceAtEnd = openingBalance?.takeIf { !spec.endDate.isBefore(it.date) }?.let { opening ->
            val movement = transactions
                .filter { !it.date.isBefore(opening.date) && !it.date.isAfter(spec.endDate) }
                .sumOf { if (it.type == TransactionType.INCOME) it.amountPence else -it.amountPence }
            opening.amountPence + movement
        }

        val document = PdfDocument()
        val writer = PdfWriter(document)

        writer.title("T Automotive")
        writer.subtitle("Cash Flow Report")
        writer.small("${spec.periodLabel}  •  ${formatDate(spec.startDate)} – ${formatDate(spec.endDate)}")
        writer.small("Generated ${formatDate(LocalDate.now())}  •  Recorded data only — no estimates or projections")
        writer.space(14f)

        writer.section("Summary")
        writer.keyValue("Recorded income", formatMoney(income), Color.rgb(24, 132, 83))
        writer.keyValue("Recorded expenses", formatMoney(expenses), Color.rgb(190, 49, 49))
        writer.keyValue("Net profit", formatMoney(net), if (net >= 0) Color.rgb(24, 132, 83) else Color.rgb(190, 49, 49))
        writer.keyValue("Transactions", selected.size.toString())
        writer.keyValue("Receipts attached", receiptCount.toString())

        if (openingBalance != null) {
            writer.space(6f)
            writer.section("Tracked bank position")
            writer.keyValue("Starting balance", "${formatMoney(openingBalance.amountPence)} on ${formatDate(openingBalance.date)}")
            if (trackedBalanceAtEnd != null) {
                writer.keyValue("Tracked balance at ${formatDate(spec.endDate)}", formatMoney(trackedBalanceAtEnd))
            } else {
                writer.small("The selected report ends before your tracking start date, so no tracked balance is shown.")
            }
            if (openingBalance.date.isAfter(spec.startDate)) {
                writer.small("Tracking began ${formatDate(openingBalance.date)}. Earlier figures in this report may be incomplete unless you have backfilled them.")
            }
        }

        writer.space(12f)
        writer.section("Expense categories")
        val expenseGroups = selected.filter { it.type == TransactionType.EXPENSE }
            .groupBy { it.category.ifBlank { "Uncategorised" } }
            .mapValues { (_, items) -> items.sumOf { it.amountPence } }
            .toList()
            .sortedByDescending { it.second }
        if (expenseGroups.isEmpty()) writer.small("No recorded expenses in this period.")
        else expenseGroups.forEach { (category, total) -> writer.keyValue(category, formatMoney(total), Color.rgb(190, 49, 49)) }

        writer.space(12f)
        writer.section("Income categories")
        val incomeGroups = selected.filter { it.type == TransactionType.INCOME }
            .groupBy { it.category.ifBlank { "Uncategorised" } }
            .mapValues { (_, items) -> items.sumOf { it.amountPence } }
            .toList()
            .sortedByDescending { it.second }
        if (incomeGroups.isEmpty()) writer.small("No recorded income in this period.")
        else incomeGroups.forEach { (category, total) -> writer.keyValue(category, formatMoney(total), Color.rgb(24, 132, 83)) }

        writer.space(16f)
        writer.section("Transactions")
        if (selected.isEmpty()) {
            writer.small("No transactions recorded in this period.")
        } else {
            selected.forEach { transaction ->
                writer.transaction(transaction)
            }
        }

        if (spec.includeReceiptImages && receiptCount > 0) {
            writer.pageBreak()
            writer.section("Receipt appendix")
            writer.small("Receipt images attached to transactions in this report period.")
            writer.space(8f)

            selected.filter { it.receiptFileName.isNotBlank() }.forEach { transaction ->
                val receiptFile = ReceiptStorage.file(context, transaction.receiptFileName)
                if (receiptFile.exists() && receiptFile.length() > 0L) {
                    writer.receiptHeading(transaction)
                    val bitmap = decodeSampledBitmap(receiptFile, 1400, 1800)
                    if (bitmap != null) {
                        writer.bitmap(bitmap)
                        bitmap.recycle()
                    } else {
                        writer.small("Receipt image could not be decoded.")
                    }
                    writer.space(12f)
                }
            }
        }

        writer.finish()
        return document
    }

    private fun formatMoney(pence: Long): String = moneyFormat.format(pence / 100.0)
    private fun formatDate(date: LocalDate): String = date.format(dateFormat)

    private fun decodeSampledBitmap(file: File, reqWidth: Int, reqHeight: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (bounds.outWidth / sample > reqWidth * 2 || bounds.outHeight / sample > reqHeight * 2) {
            sample *= 2
        }
        return BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
    }

    private class PdfWriter(private val document: PdfDocument) {
        private var pageNumber = 0
        private var page: PdfDocument.Page? = null
        private var canvas: Canvas? = null
        private var y = MARGIN

        private val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(31, 42, 46)
            textSize = 24f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        private val subtitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(31, 42, 46)
            textSize = 16f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        private val sectionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(31, 42, 46)
            textSize = 13f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(44, 52, 55)
            textSize = 10.5f
        }
        private val boldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(44, 52, 55)
            textSize = 10.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        private val smallPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(100, 108, 111)
            textSize = 8.5f
        }
        private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(220, 224, 225)
            strokeWidth = 1f
        }

        init { startPage() }

        fun title(text: String) = drawLine(text, titlePaint, 30f)
        fun subtitle(text: String) = drawLine(text, subtitlePaint, 22f)
        fun small(text: String) = drawWrapped(text, smallPaint, 12f)

        fun section(text: String) {
            ensure(30f)
            canvas?.drawText(text, MARGIN, y, sectionPaint)
            y += 18f
            canvas?.drawLine(MARGIN, y, PAGE_WIDTH - MARGIN, y, linePaint)
            y += 10f
        }

        fun keyValue(label: String, value: String, valueColor: Int? = null) {
            ensure(19f)
            canvas?.drawText(label, MARGIN, y, bodyPaint)
            val oldColor = boldPaint.color
            if (valueColor != null) boldPaint.color = valueColor
            val width = boldPaint.measureText(value)
            canvas?.drawText(value, PAGE_WIDTH - MARGIN - width, y, boldPaint)
            boldPaint.color = oldColor
            y += 17f
        }

        fun transaction(transaction: MoneyTransaction) {
            val details = buildList {
                if (transaction.category.isNotBlank()) add(transaction.category)
                if (transaction.description.isNotBlank()) add(transaction.description)
            }.joinToString(" — ").ifBlank { "No description" }
            val extra = buildList {
                if (transaction.customerSupplier.isNotBlank()) add("Customer/Supplier: ${transaction.customerSupplier}")
                if (transaction.vehicleRegistration.isNotBlank()) add("Reg: ${transaction.vehicleRegistration}")
                if (transaction.jobReference.isNotBlank()) add("Job: ${transaction.jobReference}")
                if (transaction.paymentMethod.isNotBlank()) add("Method: ${transaction.paymentMethod}")
                if (transaction.receiptFileName.isNotBlank()) add("Receipt attached")
            }.joinToString("  •  ")
            val note = transaction.notes.trim()
            val estimatedHeight = 56f + (if (extra.isNotBlank()) 14f else 0f) + (if (note.isNotBlank()) 14f else 0f)
            ensure(estimatedHeight)

            val typeLabel = if (transaction.type == TransactionType.INCOME) "IN" else "OUT"
            val amountText = (if (transaction.type == TransactionType.INCOME) "+" else "−") + formatMoney(transaction.amountPence)
            val amountColor = if (transaction.type == TransactionType.INCOME) Color.rgb(24, 132, 83) else Color.rgb(190, 49, 49)

            canvas?.drawText("${formatDate(transaction.date)}  •  $typeLabel", MARGIN, y, boldPaint)
            val oldColor = boldPaint.color
            boldPaint.color = amountColor
            val amountWidth = boldPaint.measureText(amountText)
            canvas?.drawText(amountText, PAGE_WIDTH - MARGIN - amountWidth, y, boldPaint)
            boldPaint.color = oldColor
            y += 15f
            drawWrapped(details, bodyPaint, 13f)
            if (extra.isNotBlank()) drawWrapped(extra, smallPaint, 11f)
            if (note.isNotBlank()) drawWrapped("Note: $note", smallPaint, 11f)
            y += 5f
            canvas?.drawLine(MARGIN, y, PAGE_WIDTH - MARGIN, y, linePaint)
            y += 10f
        }

        fun receiptHeading(transaction: MoneyTransaction) {
            ensure(50f)
            drawLine("${formatDate(transaction.date)} • ${transaction.category.ifBlank { "Transaction" }} • ${formatMoney(transaction.amountPence)}", boldPaint, 15f)
            val descriptor = listOf(transaction.description, transaction.customerSupplier, transaction.vehicleRegistration)
                .filter { it.isNotBlank() }
                .joinToString(" • ")
            if (descriptor.isNotBlank()) small(descriptor)
            space(5f)
        }

        fun bitmap(bitmap: Bitmap) {
            val maxWidth = CONTENT_WIDTH
            val maxHeight = PAGE_HEIGHT - MARGIN - y - 20f
            if (maxHeight < 180f) {
                pageBreak()
            }
            val availableHeight = PAGE_HEIGHT - MARGIN - y - 20f
            val scale = min(maxWidth / bitmap.width.toFloat(), availableHeight / bitmap.height.toFloat())
            val drawWidth = bitmap.width * scale
            val drawHeight = bitmap.height * scale
            val left = MARGIN + (CONTENT_WIDTH - drawWidth) / 2f
            val dest = android.graphics.RectF(left, y, left + drawWidth, y + drawHeight)
            canvas?.drawBitmap(bitmap, null, dest, null)
            y += drawHeight + 5f
        }

        fun space(amount: Float) {
            ensure(amount)
            y += amount
        }

        fun pageBreak() {
            finishPage()
            startPage()
        }

        fun finish() {
            finishPage()
        }

        private fun drawLine(text: String, paint: Paint, lineHeight: Float) {
            ensure(lineHeight)
            canvas?.drawText(text, MARGIN, y, paint)
            y += lineHeight
        }

        private fun drawWrapped(text: String, paint: Paint, lineHeight: Float) {
            val lines = wrapText(text, paint, CONTENT_WIDTH)
            lines.forEach { line ->
                ensure(lineHeight + 2f)
                canvas?.drawText(line, MARGIN, y, paint)
                y += lineHeight
            }
        }

        private fun ensure(height: Float) {
            if (y + height > PAGE_HEIGHT - MARGIN) pageBreak()
        }

        private fun startPage() {
            pageNumber++
            val info = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create()
            page = document.startPage(info)
            canvas = page?.canvas
            y = MARGIN
            val footer = "T Automotive Cash Flow"
            canvas?.drawText(footer, MARGIN, PAGE_HEIGHT - 18f, smallPaint)
            val pageText = "Page $pageNumber"
            canvas?.drawText(pageText, PAGE_WIDTH - MARGIN - smallPaint.measureText(pageText), PAGE_HEIGHT - 18f, smallPaint)
        }

        private fun finishPage() {
            page?.let { document.finishPage(it) }
            page = null
            canvas = null
        }

        private fun wrapText(text: String, paint: Paint, maxWidth: Float): List<String> {
            if (text.isBlank()) return listOf("")
            val result = mutableListOf<String>()
            text.split('\n').forEach { paragraph ->
                if (paragraph.isBlank()) {
                    result += ""
                    return@forEach
                }
                val words = paragraph.split(Regex("\\s+"))
                var line = ""
                words.forEach { word ->
                    val candidate = if (line.isBlank()) word else "$line $word"
                    if (paint.measureText(candidate) <= maxWidth) {
                        line = candidate
                    } else {
                        if (line.isNotBlank()) result += line
                        line = word
                    }
                }
                if (line.isNotBlank()) result += line
            }
            return result
        }
    }
}
