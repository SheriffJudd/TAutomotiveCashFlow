package com.tautomotive.cashflow.ui.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tautomotive.cashflow.data.MoneyTransaction
import com.tautomotive.cashflow.data.TransactionType
import com.tautomotive.cashflow.ui.components.ReportDateRange
import com.tautomotive.cashflow.ui.components.TransactionRow
import com.tautomotive.cashflow.ui.components.currentTaxYearStartYear
import com.tautomotive.cashflow.ui.components.formatShortDate
import com.tautomotive.cashflow.ui.components.isWithin
import com.tautomotive.cashflow.ui.components.taxYearRange
import java.time.LocalDate
import java.time.YearMonth

private enum class TransactionFilter { ALL, INCOME, EXPENSE }
private enum class TransactionPeriod { ALL, MONTH, TAX_YEAR, CUSTOM }

@Composable
fun TransactionsScreen(
    transactions: List<MoneyTransaction>,
    onEdit: (Long) -> Unit,
    onDelete: (Long) -> Unit
) {
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf(TransactionFilter.ALL) }
    var period by remember { mutableStateOf(TransactionPeriod.ALL) }
    val today = LocalDate.now()
    var customStart by remember { mutableStateOf(LocalDate.of(currentTaxYearStartYear(today), 4, 6)) }
    var customEnd by remember { mutableStateOf(today) }
    val context = LocalContext.current

    val activeRange: ReportDateRange? = when (period) {
        TransactionPeriod.ALL -> null
        TransactionPeriod.MONTH -> ReportDateRange(YearMonth.from(today).atDay(1), today)
        TransactionPeriod.TAX_YEAR -> taxYearRange(currentTaxYearStartYear(today), today)
        TransactionPeriod.CUSTOM -> ReportDateRange(customStart, customEnd)
    }

    val visible = transactions.filter { item ->
        val typeMatches = when (filter) {
            TransactionFilter.ALL -> true
            TransactionFilter.INCOME -> item.type == TransactionType.INCOME
            TransactionFilter.EXPENSE -> item.type == TransactionType.EXPENSE
        }
        val textMatches = query.isBlank() || listOf(
            item.description,
            item.category,
            item.customerSupplier,
            item.jobReference,
            item.vehicleRegistration,
            item.paymentMethod,
            item.notes
        ).any { it.contains(query, ignoreCase = true) }
        val dateMatches = activeRange == null || item.date.isWithin(activeRange)
        typeMatches && textMatches && dateMatches
    }

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Text(
            "Transactions",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 16.dp, bottom = 10.dp)
        )

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
            placeholder = { Text("Search customer, reg, job, category…") },
            shape = RoundedCornerShape(16.dp)
        )

        Row(
            modifier = Modifier.padding(top = 10.dp).horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = filter == TransactionFilter.ALL,
                onClick = { filter = TransactionFilter.ALL },
                label = { Text("All") }
            )
            FilterChip(
                selected = filter == TransactionFilter.INCOME,
                onClick = { filter = TransactionFilter.INCOME },
                label = { Text("Income") }
            )
            FilterChip(
                selected = filter == TransactionFilter.EXPENSE,
                onClick = { filter = TransactionFilter.EXPENSE },
                label = { Text("Expenses") }
            )
        }

        Row(
            modifier = Modifier.padding(top = 6.dp).horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TransactionPeriod.entries.forEach { item ->
                FilterChip(
                    selected = period == item,
                    onClick = { period = item },
                    label = {
                        Text(
                            when (item) {
                                TransactionPeriod.ALL -> "Any date"
                                TransactionPeriod.MONTH -> "This month"
                                TransactionPeriod.TAX_YEAR -> "Tax year"
                                TransactionPeriod.CUSTOM -> "Custom"
                            }
                        )
                    }
                )
            }
        }

        if (period == TransactionPeriod.CUSTOM) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        DatePickerDialog(
                            context,
                            { _, y, m, d ->
                                val picked = LocalDate.of(y, m + 1, d)
                                customStart = picked
                                if (customEnd.isBefore(picked)) customEnd = picked
                            },
                            customStart.year,
                            customStart.monthValue - 1,
                            customStart.dayOfMonth
                        ).show()
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("From ${formatShortDate(customStart)}")
                }
                OutlinedButton(
                    onClick = {
                        DatePickerDialog(
                            context,
                            { _, y, m, d ->
                                val picked = LocalDate.of(y, m + 1, d)
                                customEnd = picked
                                if (customStart.isAfter(picked)) customStart = picked
                            },
                            customEnd.year,
                            customEnd.monthValue - 1,
                            customEnd.dayOfMonth
                        ).show()
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("To ${formatShortDate(customEnd)}")
                }
            }
        }

        if (activeRange != null) {
            Text(
                "${formatShortDate(activeRange.start)} – ${formatShortDate(activeRange.end)}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 6.dp)
            )
        }

        Text(
            "${visible.size} ${if (visible.size == 1) "entry" else "entries"}",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 6.dp, bottom = 8.dp)
        )

        if (visible.isEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
                shape = RoundedCornerShape(18.dp)
            ) {
                Text(
                    if (transactions.isEmpty()) "No transactions recorded yet." else "No transactions match these filters.",
                    modifier = Modifier.padding(20.dp)
                )
            }
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(visible, key = { it.id }) { transaction ->
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        TransactionRow(
                            transaction = transaction,
                            onClick = { onEdit(transaction.id) },
                            onDelete = { onDelete(transaction.id) },
                            modifier = Modifier.padding(horizontal = 12.dp)
                        )
                    }
                }
            }
        }
    }
}
