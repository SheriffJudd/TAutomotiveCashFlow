package com.tautomotive.cashflow.ui.screens

import android.app.DatePickerDialog
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.CameraAlt
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.tautomotive.cashflow.data.CategorySettings
import com.tautomotive.cashflow.data.MoneyTransaction
import com.tautomotive.cashflow.data.ReceiptStorage
import com.tautomotive.cashflow.data.TransactionType
import com.tautomotive.cashflow.ui.components.formatDate
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.LocalDate
import java.util.Locale

@Composable
fun AddEditTransactionScreen(
    existing: MoneyTransaction?,
    categorySettings: CategorySettings,
    defaultType: TransactionType = TransactionType.INCOME,
    onBack: () -> Unit,
    onSave: (MoneyTransaction) -> Unit
) {
    var type by remember(existing?.id, defaultType) { mutableStateOf(existing?.type ?: defaultType) }
    var amount by remember(existing?.id) {
        mutableStateOf(existing?.let { BigDecimal(it.amountPence).divide(BigDecimal(100)).toPlainString() } ?: "")
    }
    var description by remember(existing?.id) { mutableStateOf(existing?.description ?: "") }
    var category by remember(existing?.id) {
        mutableStateOf(existing?.category ?: categorySettings.active(defaultType).first())
    }
    var date by remember(existing?.id) { mutableStateOf(existing?.date ?: LocalDate.now()) }
    var paymentMethod by remember(existing?.id) { mutableStateOf(existing?.paymentMethod ?: "") }
    var customerSupplier by remember(existing?.id) { mutableStateOf(existing?.customerSupplier ?: "") }
    var jobReference by remember(existing?.id) { mutableStateOf(existing?.jobReference ?: "") }
    var vehicleRegistration by remember(existing?.id) { mutableStateOf(existing?.vehicleRegistration ?: "") }
    var notes by remember(existing?.id) { mutableStateOf(existing?.notes ?: "") }
    var receiptFileName by remember(existing?.id) { mutableStateOf(existing?.receiptFileName ?: "") }
    var pendingCameraFileName by remember { mutableStateOf<String?>(null) }
    var categoryMenuOpen by remember { mutableStateOf(false) }
    var paymentMenuOpen by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current
    val activeCategories = categorySettings.active(type)
    val categories = if (existing != null && existing.type == type && existing.category !in activeCategories) {
        listOf(existing.category) + activeCategories
    } else activeCategories

    val galleryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            runCatching { ReceiptStorage.copyFromUri(context, uri) }
                .onSuccess {
                    receiptFileName = it
                    error = null
                }
                .onFailure { error = "Could not attach receipt: ${it.message ?: "Unknown error"}" }
        }
    }

    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        val name = pendingCameraFileName
        if (success && name != null) {
            receiptFileName = name
            error = null
        } else if (name != null) {
            ReceiptStorage.file(context, name).delete()
        }
        pendingCameraFileName = null
    }

    fun changeType(newType: TransactionType) {
        type = newType
        val valid = categorySettings.active(newType)
        if (category !in valid) category = valid.first()
    }

    fun openReceipt() {
        if (receiptFileName.isBlank()) return
        runCatching {
            val uri = ReceiptStorage.contentUri(context, receiptFileName)
            context.startActivity(
                Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "image/*")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
            )
        }.onFailure {
            error = "Could not open receipt image."
        }
    }

    Scaffold(
        topBar = {
            Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp)) {
                IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, "Back") }
                Text(
                    if (existing == null) "Add transaction" else "Edit transaction",
                    style = MaterialTheme.typography.headlineSmall,
                    modifier = Modifier.padding(top = 9.dp)
                )
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FilterChip(
                    selected = type == TransactionType.INCOME,
                    onClick = { changeType(TransactionType.INCOME) },
                    label = { Text("Income") }
                )
                FilterChip(
                    selected = type == TransactionType.EXPENSE,
                    onClick = { changeType(TransactionType.EXPENSE) },
                    label = { Text("Expense") }
                )
            }

            OutlinedTextField(
                value = amount,
                onValueChange = { amount = it },
                label = { Text("Amount (£)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Description") },
                placeholder = { Text("e.g. Sprinter brake service") },
                modifier = Modifier.fillMaxWidth()
            )

            Column {
                OutlinedButton(onClick = { categoryMenuOpen = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Category: $category")
                }
                DropdownMenu(expanded = categoryMenuOpen, onDismissRequest = { categoryMenuOpen = false }) {
                    categories.forEach { item ->
                        DropdownMenuItem(
                            text = { Text(item) },
                            onClick = {
                                category = item
                                categoryMenuOpen = false
                            }
                        )
                    }
                }
            }

            OutlinedButton(
                onClick = {
                    DatePickerDialog(
                        context,
                        { _, year, month, day -> date = LocalDate.of(year, month + 1, day) },
                        date.year,
                        date.monthValue - 1,
                        date.dayOfMonth
                    ).show()
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Date: ${formatDate(date)}")
            }

            OutlinedTextField(
                value = customerSupplier,
                onValueChange = { customerSupplier = it },
                label = { Text(if (type == TransactionType.INCOME) "Customer (optional)" else "Supplier (optional)") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = jobReference,
                onValueChange = { jobReference = it },
                label = { Text("Job / reference (optional)") },
                placeholder = { Text("e.g. Job 1042") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = vehicleRegistration,
                onValueChange = { vehicleRegistration = it.uppercase(Locale.UK) },
                label = { Text("Vehicle registration (optional)") },
                placeholder = { Text("e.g. AB12 CDE") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Column {
                OutlinedButton(onClick = { paymentMenuOpen = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Payment method: ${paymentMethod.ifBlank { "Not specified" }}")
                }
                DropdownMenu(expanded = paymentMenuOpen, onDismissRequest = { paymentMenuOpen = false }) {
                    listOf("", "Bank transfer", "Cash", "Card", "Other").forEach { method ->
                        DropdownMenuItem(
                            text = { Text(method.ifBlank { "Not specified" }) },
                            onClick = {
                                paymentMethod = method
                                paymentMenuOpen = false
                            }
                        )
                    }
                }
            }

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Notes (optional)") },
                minLines = 3,
                modifier = Modifier.fillMaxWidth()
            )

            if (type == TransactionType.EXPENSE || receiptFileName.isNotBlank()) {
            Card(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Outlined.ReceiptLong, contentDescription = null)
                            Text("Receipt", style = MaterialTheme.typography.titleMedium)
                        }
    
                        if (receiptFileName.isBlank()) {
                            Text(
                                "No receipt attached.",
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(
                                    onClick = { galleryLauncher.launch("image/*") },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Outlined.PhotoLibrary, contentDescription = null)
                                    Text("  Gallery")
                                }
                                OutlinedButton(
                                    onClick = {
                                        runCatching {
                                            val name = ReceiptStorage.createFileName("jpg")
                                            ReceiptStorage.createEmpty(context, name)
                                            pendingCameraFileName = name
                                            cameraLauncher.launch(ReceiptStorage.contentUri(context, name))
                                        }.onFailure {
                                            error = "Could not open camera: ${it.message ?: "Unknown error"}"
                                        }
                                    },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Outlined.CameraAlt, contentDescription = null)
                                    Text("  Camera")
                                }
                            }
                        } else {
                            Text("Receipt attached", color = MaterialTheme.colorScheme.primary)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = ::openReceipt, modifier = Modifier.weight(1f)) {
                                    Icon(Icons.Outlined.Visibility, contentDescription = null)
                                    Text("  View")
                                }
                                OutlinedButton(
                                    onClick = { receiptFileName = "" },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Outlined.DeleteOutline, contentDescription = null)
                                    Text("  Remove")
                                }
                            }
                        }
                    }
                }
    
            }

            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }

            Button(
                onClick = {
                    val parsed = amount.toBigDecimalOrNull()
                    if (parsed == null || parsed <= BigDecimal.ZERO) {
                        error = "Enter a valid amount greater than £0."
                        return@Button
                    }
                    if (description.trim().isBlank()) {
                        error = "Enter a description for this transaction."
                        return@Button
                    }
                    val pence = parsed.multiply(BigDecimal(100)).setScale(0, RoundingMode.HALF_UP).longValueExact()
                    onSave(
                        MoneyTransaction(
                            id = existing?.id ?: 0,
                            type = type,
                            amountPence = pence,
                            category = category,
                            description = description.trim(),
                            date = date,
                            paymentMethod = paymentMethod.trim(),
                            customerSupplier = customerSupplier.trim(),
                            jobReference = jobReference.trim(),
                            vehicleRegistration = vehicleRegistration.trim(),
                            notes = notes.trim(),
                            receiptFileName = receiptFileName
                        )
                    )
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (existing == null) "Save transaction" else "Save changes")
            }
        }
    }
}
