package com.tautomotive.cashflow.data

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File
import java.util.UUID

object ReceiptStorage {
    private fun dir(context: Context): File = File(context.filesDir, "receipts").apply { mkdirs() }

    fun createFileName(extension: String = "jpg"): String =
        "receipt_${System.currentTimeMillis()}_${UUID.randomUUID()}.$extension"

    fun file(context: Context, fileName: String): File = File(dir(context), File(fileName).name)

    fun createEmpty(context: Context, fileName: String): File = file(context, fileName).apply {
        parentFile?.mkdirs()
        if (!exists()) createNewFile()
    }

    fun copyFromUri(context: Context, uri: Uri): String {
        val mime = context.contentResolver.getType(uri).orEmpty()
        val ext = when {
            mime.contains("png", ignoreCase = true) -> "png"
            mime.contains("webp", ignoreCase = true) -> "webp"
            else -> "jpg"
        }
        val name = createFileName(ext)
        val target = file(context, name)
        context.contentResolver.openInputStream(uri)?.use { input ->
            target.outputStream().use { output -> input.copyTo(output) }
        } ?: error("Could not open selected receipt")
        return name
    }

    fun contentUri(context: Context, fileName: String): Uri =
        FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file(context, fileName)
        )
}
