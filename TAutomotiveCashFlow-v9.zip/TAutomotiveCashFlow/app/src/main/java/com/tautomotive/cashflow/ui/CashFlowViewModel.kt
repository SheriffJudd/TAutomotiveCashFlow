package com.tautomotive.cashflow.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tautomotive.cashflow.data.AutoBackupManager
import com.tautomotive.cashflow.data.BackupManager
import com.tautomotive.cashflow.data.CashFlowDatabase
import com.tautomotive.cashflow.data.CashFlowRepository
import com.tautomotive.cashflow.data.CategorySettings
import com.tautomotive.cashflow.data.CategoryStore
import com.tautomotive.cashflow.data.TransactionType
import com.tautomotive.cashflow.data.MoneyTransaction
import com.tautomotive.cashflow.data.OpeningBalance
import com.tautomotive.cashflow.data.OpeningBalanceStore
import com.tautomotive.cashflow.data.PdfReportManager
import com.tautomotive.cashflow.data.PdfReportSpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext


data class BackupSafetyState(
    val folderName: String? = null,
    val lastBackupText: String? = null,
    val lastError: String? = null
) {
    val enabled: Boolean get() = folderName != null
}

class CashFlowViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = CashFlowRepository(CashFlowDatabase(application))
    private val backupMutex = Mutex()

    private val _transactions = MutableStateFlow<List<MoneyTransaction>>(emptyList())
    val transactions: StateFlow<List<MoneyTransaction>> = _transactions.asStateFlow()

    private val _openingBalance = MutableStateFlow(OpeningBalanceStore.load(application))
    val openingBalance: StateFlow<OpeningBalance?> = _openingBalance.asStateFlow()

    private val _categorySettings = MutableStateFlow(CategoryStore.load(application))
    val categorySettings: StateFlow<CategorySettings> = _categorySettings.asStateFlow()

    private val _backupSafety = MutableStateFlow(loadBackupSafetyState())
    val backupSafety: StateFlow<BackupSafetyState> = _backupSafety.asStateFlow()

    init {
        refresh(runDailyBackup = true)
    }

    fun refresh(runDailyBackup: Boolean = false) {
        viewModelScope.launch {
            _transactions.value = withContext(Dispatchers.IO) { repository.getAll() }
            if (runDailyBackup && withContext(Dispatchers.IO) { AutoBackupManager.shouldRunDailyBackup(getApplication()) }) {
                triggerAutoBackup()
            }
        }
    }

    fun save(transaction: MoneyTransaction, onSaved: () -> Unit = {}) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { repository.save(transaction) }
            _transactions.value = withContext(Dispatchers.IO) { repository.getAll() }
            onSaved()
            triggerAutoBackup()
        }
    }

    fun delete(id: Long) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { repository.delete(id) }
            _transactions.value = withContext(Dispatchers.IO) { repository.getAll() }
            triggerAutoBackup()
        }
    }

    fun setOpeningBalance(openingBalance: OpeningBalance) {
        OpeningBalanceStore.save(getApplication(), openingBalance)
        _openingBalance.value = openingBalance
        triggerAutoBackup()
    }

    fun clearOpeningBalance() {
        OpeningBalanceStore.clear(getApplication())
        _openingBalance.value = null
        triggerAutoBackup()
    }

    fun exportBackup(uri: Uri, onResult: (Result<Unit>) -> Unit) {
        viewModelScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    BackupManager.export(getApplication(), _transactions.value, _openingBalance.value, _categorySettings.value, uri)
                }
            }
            onResult(result)
        }
    }

    fun exportCsv(uri: Uri, onResult: (Result<Unit>) -> Unit) {
        viewModelScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    BackupManager.exportCsv(getApplication(), _transactions.value, uri)
                }
            }
            onResult(result)
        }
    }


    fun exportPdf(uri: Uri, spec: PdfReportSpec, onResult: (Result<Unit>) -> Unit) {
        viewModelScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    PdfReportManager.export(
                        getApplication(),
                        _transactions.value,
                        _openingBalance.value,
                        spec,
                        uri
                    )
                }
            }
            onResult(result)
        }
    }

    fun createShareablePdf(spec: PdfReportSpec, onResult: (Result<Uri>) -> Unit) {
        viewModelScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    PdfReportManager.createShareable(
                        getApplication(),
                        _transactions.value,
                        _openingBalance.value,
                        spec
                    )
                }
            }
            onResult(result)
        }
    }

    fun importBackup(uri: Uri, onResult: (Result<Int>) -> Unit) {
        viewModelScope.launch {
            val result = runCatching {
                val backup = withContext(Dispatchers.IO) {
                    BackupManager.import(getApplication(), uri)
                }
                withContext(Dispatchers.IO) { repository.replaceAll(backup.transactions) }
                if (backup.openingBalance != null) {
                    OpeningBalanceStore.save(getApplication(), backup.openingBalance)
                } else {
                    OpeningBalanceStore.clear(getApplication())
                }
                _openingBalance.value = backup.openingBalance
                backup.categorySettings?.let { restoredCategories ->
                    CategoryStore.save(getApplication(), restoredCategories)
                    _categorySettings.value = CategoryStore.load(getApplication())
                }
                _transactions.value = withContext(Dispatchers.IO) { repository.getAll() }
                backup.transactions.size
            }
            onResult(result)
            if (result.isSuccess) triggerAutoBackup()
        }
    }

    fun configureAutoBackup(uri: Uri, onResult: (Result<Unit>) -> Unit) {
        viewModelScope.launch {
            val result = runCatching {
                backupMutex.withLock {
                    withContext(Dispatchers.IO) {
                        AutoBackupManager.setFolder(getApplication(), uri)
                        AutoBackupManager.backupNow(
                            getApplication(),
                            _transactions.value,
                            _openingBalance.value,
                            _categorySettings.value
                        )
                    }
                }
            }
            _backupSafety.value = loadBackupSafetyState()
            onResult(result.map { Unit })
        }
    }

    fun disableAutoBackup() {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { AutoBackupManager.clearFolder(getApplication()) }
            _backupSafety.value = loadBackupSafetyState()
        }
    }

    fun runAutoBackup(onResult: (Result<Unit>) -> Unit) {
        viewModelScope.launch {
            val result = runCatching {
                backupMutex.withLock {
                    withContext(Dispatchers.IO) {
                        AutoBackupManager.backupNow(
                            getApplication(),
                            _transactions.value,
                            _openingBalance.value,
                            _categorySettings.value
                        )
                    }
                }
            }
            _backupSafety.value = loadBackupSafetyState()
            onResult(result.map { Unit })
        }
    }

    fun addCategory(type: TransactionType, name: String) {
        val cleaned = name.trim()
        if (cleaned.isBlank()) return
        val current = _categorySettings.value
        val active = current.active(type)
        val archived = current.archived(type)
        if ((active + archived).any { it.equals(cleaned, ignoreCase = true) }) return

        val updated = if (type == TransactionType.INCOME) {
            current.copy(incomeCategories = active + cleaned)
        } else {
            current.copy(expenseCategories = active + cleaned)
        }
        CategoryStore.save(getApplication(), updated)
        _categorySettings.value = CategoryStore.load(getApplication())
        triggerAutoBackup()
    }

    fun renameCategory(type: TransactionType, oldName: String, newName: String) {
        val cleaned = newName.trim()
        if (cleaned.isBlank() || oldName == cleaned) return
        val current = _categorySettings.value
        val all = current.active(type) + current.archived(type)
        if (all.any { !it.equals(oldName, true) && it.equals(cleaned, true) }) return

        viewModelScope.launch {
            withContext(Dispatchers.IO) { repository.renameCategory(type, oldName, cleaned) }
            val active = current.active(type).map { if (it == oldName) cleaned else it }
            val archived = current.archived(type).map { if (it == oldName) cleaned else it }
            val updated = if (type == TransactionType.INCOME) {
                current.copy(incomeCategories = active, archivedIncomeCategories = archived)
            } else {
                current.copy(expenseCategories = active, archivedExpenseCategories = archived)
            }
            CategoryStore.save(getApplication(), updated)
            _categorySettings.value = CategoryStore.load(getApplication())
            _transactions.value = withContext(Dispatchers.IO) { repository.getAll() }
            triggerAutoBackup()
        }
    }

    fun archiveCategory(type: TransactionType, name: String) {
        val current = _categorySettings.value
        val active = current.active(type)
        if (active.size <= 1 || name !in active) return
        val updated = if (type == TransactionType.INCOME) {
            current.copy(
                incomeCategories = active - name,
                archivedIncomeCategories = (current.archivedIncomeCategories + name).distinct()
            )
        } else {
            current.copy(
                expenseCategories = active - name,
                archivedExpenseCategories = (current.archivedExpenseCategories + name).distinct()
            )
        }
        CategoryStore.save(getApplication(), updated)
        _categorySettings.value = CategoryStore.load(getApplication())
        triggerAutoBackup()
    }

    fun restoreCategory(type: TransactionType, name: String) {
        val current = _categorySettings.value
        val updated = if (type == TransactionType.INCOME) {
            current.copy(
                incomeCategories = (current.incomeCategories + name).distinct(),
                archivedIncomeCategories = current.archivedIncomeCategories - name
            )
        } else {
            current.copy(
                expenseCategories = (current.expenseCategories + name).distinct(),
                archivedExpenseCategories = current.archivedExpenseCategories - name
            )
        }
        CategoryStore.save(getApplication(), updated)
        _categorySettings.value = CategoryStore.load(getApplication())
        triggerAutoBackup()
    }

    fun resetCategories() {
        _categorySettings.value = CategoryStore.reset(getApplication())
        triggerAutoBackup()
    }

    fun find(id: Long): MoneyTransaction? = _transactions.value.firstOrNull { it.id == id }

    private fun triggerAutoBackup() {
        if (AutoBackupManager.folderUri(getApplication()) == null) return

        viewModelScope.launch {
            runCatching {
                backupMutex.withLock {
                    withContext(Dispatchers.IO) {
                        AutoBackupManager.backupNow(
                            getApplication(),
                            _transactions.value,
                            _openingBalance.value,
                            _categorySettings.value
                        )
                    }
                }
            }
            _backupSafety.value = loadBackupSafetyState()
        }
    }

    private fun loadBackupSafetyState(): BackupSafetyState = BackupSafetyState(
        folderName = AutoBackupManager.folderLabel(getApplication()),
        lastBackupText = AutoBackupManager.formatLastBackup(getApplication()),
        lastError = AutoBackupManager.lastError(getApplication())
    )
}
