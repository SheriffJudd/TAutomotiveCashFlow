package com.tautomotive.cashflow.ui.components

import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

data class ReportDateRange(val start: LocalDate, val end: LocalDate)

fun currentTaxYearStartYear(today: LocalDate = LocalDate.now()): Int {
    val thisYearStart = LocalDate.of(today.year, 4, 6)
    return if (today.isBefore(thisYearStart)) today.year - 1 else today.year
}

fun taxYearRange(startYear: Int, today: LocalDate = LocalDate.now()): ReportDateRange {
    val start = LocalDate.of(startYear, 4, 6)
    val fullEnd = LocalDate.of(startYear + 1, 4, 5)
    val currentStartYear = currentTaxYearStartYear(today)
    val end = if (startYear == currentStartYear && today.isBefore(fullEnd)) today else fullEnd
    return ReportDateRange(start, end)
}

fun calendarYearRange(year: Int, today: LocalDate = LocalDate.now()): ReportDateRange {
    val start = LocalDate.of(year, 1, 1)
    val fullEnd = LocalDate.of(year, 12, 31)
    val end = if (year == today.year && today.isBefore(fullEnd)) today else fullEnd
    return ReportDateRange(start, end)
}

fun LocalDate.isWithin(range: ReportDateRange): Boolean =
    !isBefore(range.start) && !isAfter(range.end)

fun taxYearLabel(startYear: Int): String =
    "$startYear/${(startYear + 1).toString().takeLast(2)}"

fun formatShortDate(date: LocalDate): String =
    date.format(DateTimeFormatter.ofPattern("d MMM yyyy", Locale.UK))

fun monthRange(month: YearMonth): ReportDateRange =
    ReportDateRange(month.atDay(1), month.atEndOfMonth())
