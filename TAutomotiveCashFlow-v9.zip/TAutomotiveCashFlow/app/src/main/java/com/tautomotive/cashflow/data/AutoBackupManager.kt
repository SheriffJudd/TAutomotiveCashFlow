package com.tautomotive.cashflow.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

object AutoBackupManager {
    private const val PREFS = "cashflow_backup_settings"
    private const val KEY_TREE_URI = "auto_backup_tree_uri"
    private const val KEY_LAST_BACKUP = "last_backup_epoch_ms"
    private const val KEY_LAST_ERROR = "last_backup_error"
    private const val MAX_BACKUPS = 10
    private const val PREFIX = "TAutomotive_AutoBackup_"

    private val filenameFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss-SSS")

    fun folderUri(context: Context): Uri? =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_TREE_URI, null)
            ?.let(Uri::parse)

    fun folderLabel(context: Context): String? {
        val uri = folderUri(context) ?: return null
        return runCatching { DocumentFile.fromTreeUri(context, uri)?.name }.getOrNull()
            ?: "Selected folder"
    }

    fun lastBackupAt(context: Context): Long? {
        val value = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getLong(KEY_LAST_BACKUP, 0L)
        return value.takeIf { it > 0L }
    }

    fun lastError(context: Context): String? =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_LAST_ERROR, null)

    fun setFolder(context: Context, uri: Uri) {
        val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        context.contentResolver.takePersistableUriPermission(uri, flags)
        val folder = DocumentFile.fromTreeUri(context, uri) ?: error("Could not open selected folder")
        if (!folder.exists() || !folder.isDirectory || !folder.canWrite()) {
            error("Selected folder is not writable")
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_TREE_URI, uri.toString())
            .remove(KEY_LAST_ERROR)
            .apply()
    }

    fun clearFolder(context: Context) {
        val uri = folderUri(context)
        if (uri != null) {
            val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            runCatching { context.contentResolver.releasePersistableUriPermission(uri, flags) }
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .remove(KEY_TREE_URI)
            .remove(KEY_LAST_ERROR)
            .apply()
    }

    fun shouldRunDailyBackup(context: Context): Boolean {
        if (folderUri(context) == null) return false
        val last = lastBackupAt(context) ?: return true
        return System.currentTimeMillis() - last >= 24L * 60L * 60L * 1000L
    }

    fun backupNow(
        context: Context,
        transactions: List<MoneyTransaction>,
        openingBalance: OpeningBalance?,
        categorySettings: CategorySettings
    ): Uri {
        val treeUri = folderUri(context) ?: error("Choose an automatic backup folder first")
        val folder = DocumentFile.fromTreeUri(context, treeUri) ?: error("Backup folder is no longer available")
        if (!folder.canWrite()) error("Backup folder is no longer writable")

        val stamp = LocalDateTime.now().format(filenameFormatter)
        val filename = "$PREFIX$stamp.zip"
        val document = folder.createFile("application/zip", filename)
            ?: error("Could not create backup file in selected folder")

        return try {
            BackupManager.export(context, transactions, openingBalance, categorySettings, document.uri)
            recordSuccess(context)
            prune(folder)
            document.uri
        } catch (t: Throwable) {
            runCatching { document.delete() }
            recordFailure(context, t.message ?: "Automatic backup failed")
            throw t
        }
    }

    private fun prune(folder: DocumentFile) {
        val backups = folder.listFiles()
            .filter { it.isFile && it.name?.startsWith(PREFIX) == true && it.name?.endsWith(".zip") == true }
            .sortedByDescending { it.name }
        backups.drop(MAX_BACKUPS).forEach { runCatching { it.delete() } }
    }

    private fun recordSuccess(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putLong(KEY_LAST_BACKUP, System.currentTimeMillis())
            .remove(KEY_LAST_ERROR)
            .apply()
    }

    private fun recordFailure(context: Context, message: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_LAST_ERROR, message)
            .apply()
    }

    fun formatLastBackup(context: Context): String? {
        val last = lastBackupAt(context) ?: return null
        val local = Instant.ofEpochMilli(last).atZone(ZoneId.systemDefault()).toLocalDateTime()
        return local.format(DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm"))
    }
}
