package com.tautomotive.cashflow.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tautomotive.cashflow.data.MoneyTransaction
import com.tautomotive.cashflow.data.TransactionType
import com.tautomotive.cashflow.ui.components.TransactionRow
import com.tautomotive.cashflow.ui.components.formatDate
import com.tautomotive.cashflow.ui.components.formatMoney
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.TextStyle
import java.util.Locale

@Composable
fun CalendarScreen(transactions: List<MoneyTransaction>) {
    var month by remember { mutableStateOf(YearMonth.now()) }
    var selectedDate by remember { mutableStateOf(LocalDate.now()) }

    val first = month.atDay(1)
    val leading = first.dayOfWeek.value - 1
    val days = buildList<LocalDate?> {
        repeat(leading) { add(null) }
        for (day in 1..month.lengthOfMonth()) add(month.atDay(day))
    }

    val monthTransactions = transactions.filter { YearMonth.from(it.date) == month }
    val monthIncome = monthTransactions.filter { it.type == TransactionType.INCOME }.sumOf { it.amountPence }
    val monthExpenses = monthTransactions.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amountPence }
    val selectedTransactions = transactions.filter { it.date == selectedDate }

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 12.dp)) {
        Text(
            "Calendar",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = {
                month = month.minusMonths(1)
                selectedDate = month.atDay(1)
            }) { Icon(Icons.Outlined.ChevronLeft, "Previous month") }

            Text(
                "${month.month.getDisplayName(TextStyle.FULL, Locale.UK)} ${month.year}",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )

            IconButton(onClick = {
                month = month.plusMonths(1)
                selectedDate = month.atDay(1)
            }) { Icon(Icons.Outlined.ChevronRight, "Next month") }
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            CalendarSummaryCard(
                label = "In",
                value = monthIncome,
                income = true,
                modifier = Modifier.weight(1f)
            )
            CalendarSummaryCard(
                label = "Out",
                value = monthExpenses,
                income = false,
                modifier = Modifier.weight(1f)
            )
        }

        Row(modifier = Modifier.fillMaxWidth()) {
            listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun").forEach {
                Box(
                    modifier = Modifier.weight(1f).padding(vertical = 5.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        it,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(7),
            modifier = Modifier.fillMaxWidth().weight(1f)
        ) {
            items(days) { date ->
                if (date == null) {
                    Box(Modifier.aspectRatio(0.88f))
                } else {
                    val dayTransactions = transactions.filter { it.date == date }
                    val hasIncome = dayTransactions.any { it.type == TransactionType.INCOME }
                    val hasExpense = dayTransactions.any { it.type == TransactionType.EXPENSE }
                    val selected = date == selectedDate
                    val isToday = date == LocalDate.now()

                    Column(
                        modifier = Modifier
                            .aspectRatio(0.88f)
                            .padding(2.dp)
                            .background(
                                when {
                                    selected -> MaterialTheme.colorScheme.secondaryContainer
                                    else -> MaterialTheme.colorScheme.surface
                                },
                                RoundedCornerShape(12.dp)
                            )
                            .clickable { selectedDate = date }
                            .padding(5.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Box(
                            modifier = if (isToday) {
                                Modifier.size(28.dp).background(MaterialTheme.colorScheme.primary, CircleShape)
                            } else Modifier.size(28.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                date.dayOfMonth.toString(),
                                fontWeight = if (selected || isToday) FontWeight.Bold else FontWeight.Medium,
                                color = if (isToday) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(3.dp), modifier = Modifier.padding(bottom = 3.dp)) {
                            if (hasIncome) {
                                Box(Modifier.size(6.dp).background(MaterialTheme.colorScheme.primary, CircleShape))
                            }
                            if (hasExpense) {
                                Box(Modifier.size(6.dp).background(MaterialTheme.colorScheme.error, CircleShape))
                            }
                        }
                    }
                }
            }
        }

        val selectedIncome = selectedTransactions.filter { it.type == TransactionType.INCOME }.sumOf { it.amountPence }
        val selectedExpense = selectedTransactions.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amountPence }

        Card(
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
            shape = RoundedCornerShape(18.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(formatDate(selectedDate), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                    "In ${formatMoney(selectedIncome)}   •   Out ${formatMoney(selectedExpense)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 2.dp, bottom = 6.dp)
                )

                if (selectedTransactions.isEmpty()) {
                    Text("No money in or out on this day.", style = MaterialTheme.typography.bodyMedium)
                } else {
                    selectedTransactions.take(4).forEach { item ->
                        TransactionRow(
                            transaction = item,
                            onClick = {},
                            onDelete = {},
                            showDelete = false
                        )
                    }
                    if (selectedTransactions.size > 4) {
                        Text(
                            "+${selectedTransactions.size - 4} more entries",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CalendarSummaryCard(
    label: String,
    value: Long,
    income: Boolean,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = if (income) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                formatMoney(value),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = if (income) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
            )
        }
    }
}
