# T Automotive Cash Flow

Offline-first Android cash-flow app for recording business income and expenses.

## Included in v1

- Dashboard with current cash position, monthly income, monthly expenses and monthly profit
- Add income and expense transactions
- Edit and delete transactions
- T Automotive-oriented categories
- Optional customer/supplier, payment method and notes
- Calendar showing daily money in and money out
- Tap a calendar date to see that day's transactions
- Annual Profit & Loss summary
- Monthly P&L breakdown
- Expense category breakdown
- Local SQLite storage; no login or cloud service required
- Light/dark mode follows the Android system setting

## Open in Android Studio

1. Open the `TAutomotiveCashFlow` folder in Android Studio.
2. Allow Gradle to sync and download the Android/Compose dependencies.
3. If Android Studio proposes an Android Gradle Plugin/Kotlin upgrade, accepting the IDE's compatible upgrade is fine.
4. Run on an Android 8.0+ device/emulator.
5. To make an installable APK in Android Studio, use **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.

The package/application id is `com.tautomotive.cashflow`.

## Data

Transactions are stored in the app's private SQLite database (`cash_flow.db`). Uninstalling the app deletes its local data, so backup/export is a recommended next feature before using it as the only accounting record.

## Good next additions

- CSV/Excel export and restore
- Receipt photos
- Recurring transactions
- Customer/job/vehicle tracking
- Search and advanced filters
- VAT mode
- Biometric/PIN lock
- Database backup to Drive/OneDrive
- Bank CSV import / reconciliation


> Note: this is a cash-flow tracker, not a substitute for formal tax/accounting records. The P&L is calculated from the transactions you enter.
