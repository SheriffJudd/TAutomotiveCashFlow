package com.tautomotive.cashflow.data

import java.time.LocalDate

enum class TransactionType { INCOME, EXPENSE }

data class MoneyTransaction(
    val id: Long = 0,
    val type: TransactionType,
    val amountPence: Long,
    val category: String,
    val description: String,
    val date: LocalDate,
    val paymentMethod: String = "",
    val customerSupplier: String = "",
    val notes: String = ""
)

val defaultIncomeCategories = listOf(
    "Mechanical work",
    "Diagnostics",
    "Tyres",
    "DPF / AdBlue",
    "Call-out",
    "Parts recharge",
    "Other income"
)

val defaultExpenseCategories = listOf(
    "Parts",
    "Fuel",
    "Tools & equipment",
    "Van costs",
    "Insurance",
    "Subcontractors",
    "Software / subscriptions",
    "Phone / internet",
    "Advertising",
    "Other expense"
)
