package com.tautomotive.cashflow.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tautomotive.cashflow.data.MoneyTransaction
import com.tautomotive.cashflow.data.TransactionType
import com.tautomotive.cashflow.ui.components.formatMoney
import java.time.LocalDate
import java.time.Month
import java.time.format.TextStyle
import java.util.Locale

@Composable
fun ProfitLossScreen(transactions: List<MoneyTransaction>) {
    var year by remember { mutableIntStateOf(LocalDate.now().year) }
    val yearly = transactions.filter { it.date.year == year }
    val income = yearly.filter { it.type == TransactionType.INCOME }.sumOf { it.amountPence }
    val expenses = yearly.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amountPence }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Profit & Loss", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { year-- }) { Icon(Icons.Outlined.ChevronLeft, "Previous year") }
            Text(year.toString(), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            IconButton(onClick = { year++ }) { Icon(Icons.Outlined.ChevronRight, "Next year") }
        }

        PnlCard("Total income", income)
        PnlCard("Total expenses", expenses)
        PnlCard("Net profit", income - expenses)

        Text("Monthly breakdown", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(14.dp)) {
                Month.entries.forEachIndexed { index, month ->
                    val monthItems = yearly.filter { it.date.month == month }
                    val monthIncome = monthItems.filter { it.type == TransactionType.INCOME }.sumOf { it.amountPence }
                    val monthExpenses = monthItems.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amountPence }
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(month.getDisplayName(TextStyle.SHORT, Locale.UK), modifier = Modifier.weight(1f))
                        Text(formatMoney(monthIncome), modifier = Modifier.weight(1.2f))
                        Text(formatMoney(monthExpenses), modifier = Modifier.weight(1.2f))
                        Text(formatMoney(monthIncome - monthExpenses), modifier = Modifier.weight(1.2f), fontWeight = FontWeight.Bold)
                    }
                    if (index < Month.entries.lastIndex) HorizontalDivider()
                }
            }
        }

        Text("Expense categories", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        val categories = yearly
            .filter { it.type == TransactionType.EXPENSE }
            .groupBy { it.category }
            .mapValues { (_, values) -> values.sumOf { it.amountPence } }
            .toList()
            .sortedByDescending { it.second }

        if (categories.isEmpty()) {
            Text("No expenses recorded for $year.")
        } else {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    categories.forEachIndexed { index, (category, total) ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(category)
                            Text(formatMoney(total), fontWeight = FontWeight.Bold)
                        }
                        if (index < categories.lastIndex) HorizontalDivider()
                    }
                }
            }
        }
    }
}

@Composable
private fun PnlCard(label: String, amount: Long) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(18.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, style = MaterialTheme.typography.titleMedium)
            Text(formatMoney(amount), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
    }
}
