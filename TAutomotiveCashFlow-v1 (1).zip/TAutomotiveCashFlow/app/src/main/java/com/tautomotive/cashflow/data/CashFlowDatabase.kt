package com.tautomotive.cashflow.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.time.LocalDate

class CashFlowDatabase(context: Context) : SQLiteOpenHelper(
    context,
    DATABASE_NAME,
    null,
    DATABASE_VERSION
) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                type TEXT NOT NULL,
                amount_pence INTEGER NOT NULL,
                category TEXT NOT NULL,
                description TEXT NOT NULL,
                transaction_date INTEGER NOT NULL,
                payment_method TEXT NOT NULL DEFAULT '',
                customer_supplier TEXT NOT NULL DEFAULT '',
                notes TEXT NOT NULL DEFAULT '',
                created_at INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL("CREATE INDEX idx_transactions_date ON transactions(transaction_date)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    fun getAllTransactions(): List<MoneyTransaction> {
        val output = mutableListOf<MoneyTransaction>()
        readableDatabase.query(
            "transactions",
            null,
            null,
            null,
            null,
            null,
            "transaction_date DESC, id DESC"
        ).use { cursor ->
            val idIx = cursor.getColumnIndexOrThrow("id")
            val typeIx = cursor.getColumnIndexOrThrow("type")
            val amountIx = cursor.getColumnIndexOrThrow("amount_pence")
            val categoryIx = cursor.getColumnIndexOrThrow("category")
            val descriptionIx = cursor.getColumnIndexOrThrow("description")
            val dateIx = cursor.getColumnIndexOrThrow("transaction_date")
            val paymentIx = cursor.getColumnIndexOrThrow("payment_method")
            val customerIx = cursor.getColumnIndexOrThrow("customer_supplier")
            val notesIx = cursor.getColumnIndexOrThrow("notes")

            while (cursor.moveToNext()) {
                output += MoneyTransaction(
                    id = cursor.getLong(idIx),
                    type = TransactionType.valueOf(cursor.getString(typeIx)),
                    amountPence = cursor.getLong(amountIx),
                    category = cursor.getString(categoryIx),
                    description = cursor.getString(descriptionIx),
                    date = LocalDate.ofEpochDay(cursor.getLong(dateIx)),
                    paymentMethod = cursor.getString(paymentIx),
                    customerSupplier = cursor.getString(customerIx),
                    notes = cursor.getString(notesIx)
                )
            }
        }
        return output
    }

    fun upsert(transaction: MoneyTransaction): Long {
        val values = ContentValues().apply {
            put("type", transaction.type.name)
            put("amount_pence", transaction.amountPence)
            put("category", transaction.category)
            put("description", transaction.description)
            put("transaction_date", transaction.date.toEpochDay())
            put("payment_method", transaction.paymentMethod)
            put("customer_supplier", transaction.customerSupplier)
            put("notes", transaction.notes)
            put("created_at", System.currentTimeMillis())
        }

        return if (transaction.id == 0L) {
            writableDatabase.insertOrThrow("transactions", null, values)
        } else {
            writableDatabase.update(
                "transactions",
                values,
                "id = ?",
                arrayOf(transaction.id.toString())
            )
            transaction.id
        }
    }

    fun delete(id: Long) {
        writableDatabase.delete("transactions", "id = ?", arrayOf(id.toString()))
    }

    companion object {
        private const val DATABASE_NAME = "cash_flow.db"
        private const val DATABASE_VERSION = 1
    }
}
