package com.tautomotive.cashflow.ui.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.tautomotive.cashflow.data.MoneyTransaction
import com.tautomotive.cashflow.data.TransactionType
import com.tautomotive.cashflow.data.defaultExpenseCategories
import com.tautomotive.cashflow.data.defaultIncomeCategories
import com.tautomotive.cashflow.ui.components.formatDate
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.LocalDate

@Composable
fun AddEditTransactionScreen(
    existing: MoneyTransaction?,
    onBack: () -> Unit,
    onSave: (MoneyTransaction) -> Unit
) {
    var type by remember(existing?.id) { mutableStateOf(existing?.type ?: TransactionType.INCOME) }
    var amount by remember(existing?.id) {
        mutableStateOf(existing?.let { BigDecimal(it.amountPence).divide(BigDecimal(100)).toPlainString() } ?: "")
    }
    var description by remember(existing?.id) { mutableStateOf(existing?.description ?: "") }
    var category by remember(existing?.id) {
        mutableStateOf(existing?.category ?: defaultIncomeCategories.first())
    }
    var date by remember(existing?.id) { mutableStateOf(existing?.date ?: LocalDate.now()) }
    var paymentMethod by remember(existing?.id) { mutableStateOf(existing?.paymentMethod ?: "") }
    var customerSupplier by remember(existing?.id) { mutableStateOf(existing?.customerSupplier ?: "") }
    var notes by remember(existing?.id) { mutableStateOf(existing?.notes ?: "") }
    var categoryMenuOpen by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current
    val categories = if (type == TransactionType.INCOME) defaultIncomeCategories else defaultExpenseCategories

    fun changeType(newType: TransactionType) {
        type = newType
        val valid = if (newType == TransactionType.INCOME) defaultIncomeCategories else defaultExpenseCategories
        if (category !in valid) category = valid.first()
    }

    Scaffold(
        topBar = {
            Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp)) {
                IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, "Back") }
                Text(
                    if (existing == null) "Add transaction" else "Edit transaction",
                    style = MaterialTheme.typography.headlineSmall,
                    modifier = Modifier.padding(top = 9.dp)
                )
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FilterChip(
                    selected = type == TransactionType.INCOME,
                    onClick = { changeType(TransactionType.INCOME) },
                    label = { Text("Income") }
                )
                FilterChip(
                    selected = type == TransactionType.EXPENSE,
                    onClick = { changeType(TransactionType.EXPENSE) },
                    label = { Text("Expense") }
                )
            }

            OutlinedTextField(
                value = amount,
                onValueChange = { amount = it },
                label = { Text("Amount (£)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Description") },
                placeholder = { Text("e.g. Sprinter brake service") },
                modifier = Modifier.fillMaxWidth()
            )

            Column {
                OutlinedButton(onClick = { categoryMenuOpen = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Category: $category")
                }
                DropdownMenu(expanded = categoryMenuOpen, onDismissRequest = { categoryMenuOpen = false }) {
                    categories.forEach { item ->
                        DropdownMenuItem(
                            text = { Text(item) },
                            onClick = {
                                category = item
                                categoryMenuOpen = false
                            }
                        )
                    }
                }
            }

            OutlinedButton(
                onClick = {
                    DatePickerDialog(
                        context,
                        { _, year, month, day -> date = LocalDate.of(year, month + 1, day) },
                        date.year,
                        date.monthValue - 1,
                        date.dayOfMonth
                    ).show()
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Date: ${formatDate(date)}")
            }

            OutlinedTextField(
                value = customerSupplier,
                onValueChange = { customerSupplier = it },
                label = { Text(if (type == TransactionType.INCOME) "Customer (optional)" else "Supplier (optional)") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = paymentMethod,
                onValueChange = { paymentMethod = it },
                label = { Text("Payment method (optional)") },
                placeholder = { Text("Bank / Cash / Card") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Notes (optional)") },
                minLines = 3,
                modifier = Modifier.fillMaxWidth()
            )

            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }

            Button(
                onClick = {
                    val parsed = amount.toBigDecimalOrNull()
                    if (parsed == null || parsed <= BigDecimal.ZERO) {
                        error = "Enter a valid amount greater than £0."
                        return@Button
                    }
                    val pence = parsed.multiply(BigDecimal(100)).setScale(0, RoundingMode.HALF_UP).longValueExact()
                    onSave(
                        MoneyTransaction(
                            id = existing?.id ?: 0,
                            type = type,
                            amountPence = pence,
                            category = category,
                            description = description.trim(),
                            date = date,
                            paymentMethod = paymentMethod.trim(),
                            customerSupplier = customerSupplier.trim(),
                            notes = notes.trim()
                        )
                    )
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (existing == null) "Save transaction" else "Save changes")
            }
        }
    }
}
