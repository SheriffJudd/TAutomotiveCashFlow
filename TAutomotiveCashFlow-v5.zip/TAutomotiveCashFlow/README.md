# T Automotive Cash Flow v5

Native Android cash-flow tracker for T Automotive.

## v5 changes

- Opening balance support with a custom amount and start date.
- Opening balance is excluded from income, expenses, tax-year totals and Profit & Loss.
- Dashboard can show a tracked balance from the opening amount plus recorded entries from the selected start date.
- Opening balance can be changed or removed from Settings without deleting transactions.
- Backups now include the opening balance as well as transactions and receipt photos.
- P&L clearly warns when the selected reporting period begins before the tracking start date.

## Existing features

- Income and expense recording.
- Receipt photos from camera or gallery.
- UK tax-year reporting (6 April to 5 April).
- Tax-year, calendar-year and custom P&L date ranges.
- Customer/supplier, job/reference and vehicle-registration fields.
- Search and transaction filters.
- Calendar view.
- Backup and restore.
- GBP formatting and red/green finance styling.

Version: 5.0
