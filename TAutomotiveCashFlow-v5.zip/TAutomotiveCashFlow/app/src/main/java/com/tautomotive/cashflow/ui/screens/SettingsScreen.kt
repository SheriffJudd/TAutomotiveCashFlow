package com.tautomotive.cashflow.ui.screens

import android.app.DatePickerDialog
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountBalance
import androidx.compose.material.icons.outlined.Backup
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Restore
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.tautomotive.cashflow.data.OpeningBalance
import com.tautomotive.cashflow.ui.components.formatDate
import com.tautomotive.cashflow.ui.components.formatMoney
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.LocalDate

@Composable
fun SettingsScreen(
    openingBalance: OpeningBalance?,
    onSetOpeningBalance: (OpeningBalance) -> Unit,
    onClearOpeningBalance: () -> Unit,
    onExport: (Uri, (Result<Unit>) -> Unit) -> Unit,
    onImport: (Uri, (Result<Int>) -> Unit) -> Unit
) {
    var status by remember { mutableStateOf<String?>(null) }
    var pendingRestore by remember { mutableStateOf<Uri?>(null) }
    var showOpeningBalanceDialog by remember { mutableStateOf(false) }
    var confirmClearOpeningBalance by remember { mutableStateOf(false) }

    val createBackup = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        if (uri != null) {
            status = "Creating backup…"
            onExport(uri) { result ->
                status = if (result.isSuccess) {
                    "Backup saved successfully."
                } else {
                    "Backup failed: ${result.exceptionOrNull()?.message ?: "Unknown error"}"
                }
            }
        }
    }

    val openBackup = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) pendingRestore = uri
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Outlined.AccountBalance, contentDescription = null)
                    Text("Opening balance", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                }

                if (openingBalance == null) {
                    Text(
                        "Set the exact bank balance at the point you start using the app for real. It is kept separate from income, expenses and P&L.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Button(
                        onClick = { showOpeningBalanceDialog = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Outlined.AccountBalance, contentDescription = null)
                        Text("  Set opening balance")
                    }
                } else {
                    Text(
                        formatMoney(openingBalance.amountPence),
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "Starting ${formatDate(openingBalance.date)} • excluded from P&L",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedButton(
                        onClick = { showOpeningBalanceDialog = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Outlined.Edit, contentDescription = null)
                        Text("  Change opening balance")
                    }
                    TextButton(
                        onClick = { confirmClearOpeningBalance = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Remove opening balance")
                    }
                }
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Backup & restore", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(
                    "Backups include all transactions, receipt photos and your opening balance. Keep a backup somewhere safe before changing phones or uninstalling the app.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Button(
                    onClick = {
                        createBackup.launch("TAutomotive_Backup_${LocalDate.now()}.zip")
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Outlined.Backup, contentDescription = null)
                    Text("  Backup data")
                }

                OutlinedButton(
                    onClick = { openBackup.launch(arrayOf("application/zip", "application/octet-stream")) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Outlined.Restore, contentDescription = null)
                    Text("  Restore backup")
                }
            }
        }

        status?.let {
            Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }

    if (showOpeningBalanceDialog) {
        OpeningBalanceDialog(
            existing = openingBalance,
            onDismiss = { showOpeningBalanceDialog = false },
            onSave = {
                onSetOpeningBalance(it)
                showOpeningBalanceDialog = false
                status = "Opening balance saved."
            }
        )
    }

    if (confirmClearOpeningBalance) {
        AlertDialog(
            onDismissRequest = { confirmClearOpeningBalance = false },
            title = { Text("Remove opening balance?") },
            text = { Text("Your transactions will stay untouched. The app will simply stop calculating a bank balance from an opening amount.") },
            confirmButton = {
                TextButton(onClick = {
                    onClearOpeningBalance()
                    confirmClearOpeningBalance = false
                    status = "Opening balance removed."
                }) { Text("Remove") }
            },
            dismissButton = {
                TextButton(onClick = { confirmClearOpeningBalance = false }) { Text("Cancel") }
            }
        )
    }

    pendingRestore?.let { uri ->
        AlertDialog(
            onDismissRequest = { pendingRestore = null },
            title = { Text("Restore backup?") },
            text = { Text("This will replace the transactions and opening balance currently stored in the app with the contents of the backup.") },
            confirmButton = {
                TextButton(onClick = {
                    pendingRestore = null
                    status = "Restoring backup…"
                    onImport(uri) { result ->
                        status = result.fold(
                            onSuccess = { count -> "Restore complete: $count transactions restored." },
                            onFailure = { error -> "Restore failed: ${error.message ?: "Unknown error"}" }
                        )
                    }
                }) { Text("Restore") }
            },
            dismissButton = {
                TextButton(onClick = { pendingRestore = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun OpeningBalanceDialog(
    existing: OpeningBalance?,
    onDismiss: () -> Unit,
    onSave: (OpeningBalance) -> Unit
) {
    val context = LocalContext.current
    var amountText by remember(existing) {
        mutableStateOf(
            existing?.let { BigDecimal(it.amountPence).divide(BigDecimal(100)).toPlainString() } ?: ""
        )
    }
    var date by remember(existing) { mutableStateOf(existing?.date ?: LocalDate.now()) }
    var validationError by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Set opening balance" else "Change opening balance") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    "Enter the exact amount shown in your bank account when you start tracking. You can type any amount, including pence or a negative overdraft balance."
                )
                OutlinedTextField(
                    value = amountText,
                    onValueChange = {
                        amountText = it
                        validationError = null
                    },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Opening bank balance (£)") },
                    placeholder = { Text("6000.00") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    supportingText = {
                        validationError?.let { Text(it) }
                    },
                    isError = validationError != null
                )
                OutlinedButton(
                    onClick = {
                        DatePickerDialog(
                            context,
                            { _, year, month, day -> date = LocalDate.of(year, month + 1, day) },
                            date.year,
                            date.monthValue - 1,
                            date.dayOfMonth
                        ).apply {
                            datePicker.maxDate = System.currentTimeMillis()
                        }.show()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Start date: ${formatDate(date)}")
                }
                Text(
                    "This amount is not treated as income and never appears in Profit & Loss.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val cleaned = amountText.trim().replace(",", "")
                val parsed = cleaned.toBigDecimalOrNull()
                if (parsed == null) {
                    validationError = "Enter a valid amount, for example 6000.00"
                    return@TextButton
                }
                val pence = runCatching {
                    parsed.multiply(BigDecimal(100)).setScale(0, RoundingMode.HALF_UP).longValueExact()
                }.getOrNull()
                if (pence == null) {
                    validationError = "Amount is too large"
                    return@TextButton
                }
                onSave(OpeningBalance(amountPence = pence, date = date))
            }) { Text("Save") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
