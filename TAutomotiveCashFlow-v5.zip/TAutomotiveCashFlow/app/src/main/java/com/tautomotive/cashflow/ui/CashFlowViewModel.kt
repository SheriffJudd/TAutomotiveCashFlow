package com.tautomotive.cashflow.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tautomotive.cashflow.data.BackupManager
import com.tautomotive.cashflow.data.CashFlowDatabase
import com.tautomotive.cashflow.data.CashFlowRepository
import com.tautomotive.cashflow.data.MoneyTransaction
import com.tautomotive.cashflow.data.OpeningBalance
import com.tautomotive.cashflow.data.OpeningBalanceStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class CashFlowViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = CashFlowRepository(CashFlowDatabase(application))

    private val _transactions = MutableStateFlow<List<MoneyTransaction>>(emptyList())
    val transactions: StateFlow<List<MoneyTransaction>> = _transactions.asStateFlow()

    private val _openingBalance = MutableStateFlow(OpeningBalanceStore.load(application))
    val openingBalance: StateFlow<OpeningBalance?> = _openingBalance.asStateFlow()

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            _transactions.value = withContext(Dispatchers.IO) { repository.getAll() }
        }
    }

    fun save(transaction: MoneyTransaction, onSaved: () -> Unit = {}) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { repository.save(transaction) }
            _transactions.value = withContext(Dispatchers.IO) { repository.getAll() }
            onSaved()
        }
    }

    fun delete(id: Long) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { repository.delete(id) }
            _transactions.value = withContext(Dispatchers.IO) { repository.getAll() }
        }
    }

    fun setOpeningBalance(openingBalance: OpeningBalance) {
        OpeningBalanceStore.save(getApplication(), openingBalance)
        _openingBalance.value = openingBalance
    }

    fun clearOpeningBalance() {
        OpeningBalanceStore.clear(getApplication())
        _openingBalance.value = null
    }

    fun exportBackup(uri: Uri, onResult: (Result<Unit>) -> Unit) {
        viewModelScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    BackupManager.export(getApplication(), _transactions.value, _openingBalance.value, uri)
                }
            }
            onResult(result)
        }
    }

    fun importBackup(uri: Uri, onResult: (Result<Int>) -> Unit) {
        viewModelScope.launch {
            val result = runCatching {
                val backup = withContext(Dispatchers.IO) {
                    BackupManager.import(getApplication(), uri)
                }
                withContext(Dispatchers.IO) { repository.replaceAll(backup.transactions) }
                if (backup.openingBalance != null) {
                    OpeningBalanceStore.save(getApplication(), backup.openingBalance)
                } else {
                    OpeningBalanceStore.clear(getApplication())
                }
                _openingBalance.value = backup.openingBalance
                _transactions.value = withContext(Dispatchers.IO) { repository.getAll() }
                backup.transactions.size
            }
            onResult(result)
        }
    }

    fun find(id: Long): MoneyTransaction? = _transactions.value.firstOrNull { it.id == id }
}
