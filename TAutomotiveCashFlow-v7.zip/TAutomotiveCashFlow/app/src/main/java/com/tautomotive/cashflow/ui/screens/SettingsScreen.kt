package com.tautomotive.cashflow.ui.screens

import android.app.DatePickerDialog
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountBalance
import androidx.compose.material.icons.outlined.Backup
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Restore
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.tautomotive.cashflow.data.OpeningBalance
import com.tautomotive.cashflow.ui.BackupSafetyState
import com.tautomotive.cashflow.ui.components.formatDate
import com.tautomotive.cashflow.ui.components.formatMoney
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.LocalDate

@Composable
fun SettingsScreen(
    openingBalance: OpeningBalance?,
    backupSafety: BackupSafetyState,
    onSetOpeningBalance: (OpeningBalance) -> Unit,
    onClearOpeningBalance: () -> Unit,
    onExport: (Uri, (Result<Unit>) -> Unit) -> Unit,
    onExportCsv: (Uri, (Result<Unit>) -> Unit) -> Unit,
    onImport: (Uri, (Result<Int>) -> Unit) -> Unit,
    onConfigureAutoBackup: (Uri, (Result<Unit>) -> Unit) -> Unit,
    onDisableAutoBackup: () -> Unit,
    onRunAutoBackup: ((Result<Unit>) -> Unit) -> Unit
) {
    var status by remember { mutableStateOf<String?>(null) }
    var pendingRestore by remember { mutableStateOf<Uri?>(null) }
    var showOpeningBalanceDialog by remember { mutableStateOf(false) }
    var confirmClearOpeningBalance by remember { mutableStateOf(false) }
    var confirmDisableAutoBackup by remember { mutableStateOf(false) }

    val createBackup = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        if (uri != null) {
            status = "Creating and verifying backup…"
            onExport(uri) { result ->
                status = if (result.isSuccess) {
                    "Backup saved and verified successfully."
                } else {
                    "Backup failed: ${result.exceptionOrNull()?.message ?: "Unknown error"}"
                }
            }
        }
    }

    val createCsv = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        if (uri != null) {
            status = "Exporting CSV…"
            onExportCsv(uri) { result ->
                status = if (result.isSuccess) {
                    "CSV exported successfully."
                } else {
                    "CSV export failed: ${result.exceptionOrNull()?.message ?: "Unknown error"}"
                }
            }
        }
    }

    val openBackup = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) pendingRestore = uri
    }

    val chooseAutoBackupFolder = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            status = "Setting up automatic backups and creating the first verified backup…"
            onConfigureAutoBackup(uri) { result ->
                status = if (result.isSuccess) {
                    "Automatic backups are on. First backup created and verified."
                } else {
                    "Could not enable automatic backups: ${result.exceptionOrNull()?.message ?: "Unknown error"}"
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Outlined.AccountBalance, contentDescription = null)
                    Text("Starting balance", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                }

                if (openingBalance == null) {
                    Text(
                        "Set the exact bank balance at the point you start tracking for real. This fixed starting point is kept separate from income, expenses and P&L.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Button(
                        onClick = { showOpeningBalanceDialog = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Outlined.AccountBalance, contentDescription = null)
                        Text("  Set starting balance")
                    }
                } else {
                    Text(
                        formatMoney(openingBalance.amountPence),
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "Fixed at ${formatDate(openingBalance.date)} • excluded from P&L",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedButton(
                        onClick = { showOpeningBalanceDialog = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Outlined.Edit, contentDescription = null)
                        Text("  Change starting balance")
                    }
                    TextButton(
                        onClick = { confirmClearOpeningBalance = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Remove starting balance")
                    }
                }
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Outlined.Folder, contentDescription = null)
                    Text("Automatic safety backups", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                }

                if (!backupSafety.enabled) {
                    Text(
                        "Off. Choose a folder and the app will create a verified ZIP backup after every data change. It also checks on app launch and keeps the latest 10 backups.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Button(
                        onClick = { chooseAutoBackupFolder.launch(null) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Outlined.Backup, contentDescription = null)
                        Text("  Choose backup folder")
                    }
                } else {
                    Text("On", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Text(
                        "Folder: ${backupSafety.folderName}",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        "Last verified backup: ${backupSafety.lastBackupText ?: "Not yet completed"}",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    backupSafety.lastError?.let { error ->
                        Text(
                            "Last backup problem: $error",
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                    Text(
                        "Each backup contains transactions, starting balance, receipt photos and a CSV copy. The app verifies the ZIP after writing it and keeps the newest 10 automatic backups.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Button(
                        onClick = {
                            status = "Creating and verifying automatic backup…"
                            onRunAutoBackup { result ->
                                status = if (result.isSuccess) {
                                    "Automatic backup created and verified."
                                } else {
                                    "Backup failed: ${result.exceptionOrNull()?.message ?: "Unknown error"}"
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Outlined.Backup, contentDescription = null)
                        Text("  Back up now")
                    }
                    OutlinedButton(
                        onClick = { chooseAutoBackupFolder.launch(null) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Change backup folder")
                    }
                    TextButton(
                        onClick = { confirmDisableAutoBackup = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Turn off automatic backups")
                    }
                }
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Manual backup & export", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(
                    "ZIP backups include all transactions, receipt photos, your starting balance and a CSV copy. Manual ZIP backups are verified after they are saved.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Button(
                    onClick = {
                        createBackup.launch("TAutomotive_Backup_${LocalDate.now()}.zip")
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Outlined.Backup, contentDescription = null)
                    Text("  Save manual ZIP backup")
                }

                OutlinedButton(
                    onClick = {
                        createCsv.launch("TAutomotive_Transactions_${LocalDate.now()}.csv")
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Export transactions as CSV")
                }

                OutlinedButton(
                    onClick = { openBackup.launch(arrayOf("application/zip", "application/octet-stream")) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Outlined.Restore, contentDescription = null)
                    Text("  Restore backup")
                }
            }
        }

        status?.let {
            Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }

    if (showOpeningBalanceDialog) {
        OpeningBalanceDialog(
            existing = openingBalance,
            onDismiss = { showOpeningBalanceDialog = false },
            onSave = {
                onSetOpeningBalance(it)
                showOpeningBalanceDialog = false
                status = "Starting balance saved. Automatic backup will include the change if enabled."
            }
        )
    }

    if (confirmClearOpeningBalance) {
        AlertDialog(
            onDismissRequest = { confirmClearOpeningBalance = false },
            title = { Text("Remove starting balance?") },
            text = { Text("Your transactions will stay untouched. The app will simply stop calculating a bank balance from a starting amount.") },
            confirmButton = {
                TextButton(onClick = {
                    onClearOpeningBalance()
                    confirmClearOpeningBalance = false
                    status = "Starting balance removed."
                }) { Text("Remove") }
            },
            dismissButton = {
                TextButton(onClick = { confirmClearOpeningBalance = false }) { Text("Cancel") }
            }
        )
    }

    if (confirmDisableAutoBackup) {
        AlertDialog(
            onDismissRequest = { confirmDisableAutoBackup = false },
            title = { Text("Turn off automatic backups?") },
            text = { Text("Existing backup files will stay in your chosen folder. The app will stop creating new automatic backups.") },
            confirmButton = {
                TextButton(onClick = {
                    onDisableAutoBackup()
                    confirmDisableAutoBackup = false
                    status = "Automatic backups turned off."
                }) { Text("Turn off") }
            },
            dismissButton = {
                TextButton(onClick = { confirmDisableAutoBackup = false }) { Text("Cancel") }
            }
        )
    }

    pendingRestore?.let { uri ->
        AlertDialog(
            onDismissRequest = { pendingRestore = null },
            title = { Text("Restore backup?") },
            text = { Text("The backup is checked before restore. If valid, it will replace the transactions and starting balance currently stored in the app.") },
            confirmButton = {
                TextButton(onClick = {
                    pendingRestore = null
                    status = "Checking and restoring backup…"
                    onImport(uri) { result ->
                        status = result.fold(
                            onSuccess = { count -> "Restore complete: $count transactions restored." },
                            onFailure = { error -> "Restore failed: ${error.message ?: "Unknown error"}" }
                        )
                    }
                }) { Text("Restore") }
            },
            dismissButton = {
                TextButton(onClick = { pendingRestore = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun OpeningBalanceDialog(
    existing: OpeningBalance?,
    onDismiss: () -> Unit,
    onSave: (OpeningBalance) -> Unit
) {
    val context = LocalContext.current
    var amountText by remember(existing) {
        mutableStateOf(
            existing?.let { BigDecimal(it.amountPence).divide(BigDecimal(100)).toPlainString() } ?: ""
        )
    }
    var date by remember(existing) { mutableStateOf(existing?.date ?: LocalDate.now()) }
    var validationError by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Set starting balance" else "Change starting balance") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    "Enter the exact amount shown in your bank account when you start tracking. You can type any amount, including pence or a negative overdraft balance."
                )
                OutlinedTextField(
                    value = amountText,
                    onValueChange = {
                        amountText = it
                        validationError = null
                    },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Starting bank balance (£)") },
                    placeholder = { Text("6000.00") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    supportingText = {
                        validationError?.let { Text(it) }
                    },
                    isError = validationError != null
                )
                OutlinedButton(
                    onClick = {
                        DatePickerDialog(
                            context,
                            { _, year, month, day -> date = LocalDate.of(year, month + 1, day) },
                            date.year,
                            date.monthValue - 1,
                            date.dayOfMonth
                        ).apply {
                            datePicker.maxDate = System.currentTimeMillis()
                        }.show()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Start date: ${formatDate(date)}")
                }
                Text(
                    "This fixed amount is not treated as income and never appears in Profit & Loss. Your tracked balance changes separately as you record transactions.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val cleaned = amountText.trim().replace(",", "")
                val parsed = cleaned.toBigDecimalOrNull()
                if (parsed == null) {
                    validationError = "Enter a valid amount, for example 6000.00"
                    return@TextButton
                }
                val pence = runCatching {
                    parsed.multiply(BigDecimal(100)).setScale(0, RoundingMode.HALF_UP).longValueExact()
                }.getOrNull()
                if (pence == null) {
                    validationError = "Amount is too large"
                    return@TextButton
                }
                onSave(OpeningBalance(amountPence = pence, date = date))
            }) { Text("Save") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
