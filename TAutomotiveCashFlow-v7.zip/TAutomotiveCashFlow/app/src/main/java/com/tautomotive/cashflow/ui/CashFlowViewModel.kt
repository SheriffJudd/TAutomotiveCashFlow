package com.tautomotive.cashflow.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tautomotive.cashflow.data.AutoBackupManager
import com.tautomotive.cashflow.data.BackupManager
import com.tautomotive.cashflow.data.CashFlowDatabase
import com.tautomotive.cashflow.data.CashFlowRepository
import com.tautomotive.cashflow.data.MoneyTransaction
import com.tautomotive.cashflow.data.OpeningBalance
import com.tautomotive.cashflow.data.OpeningBalanceStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext


data class BackupSafetyState(
    val folderName: String? = null,
    val lastBackupText: String? = null,
    val lastError: String? = null
) {
    val enabled: Boolean get() = folderName != null
}

class CashFlowViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = CashFlowRepository(CashFlowDatabase(application))
    private val backupMutex = Mutex()

    private val _transactions = MutableStateFlow<List<MoneyTransaction>>(emptyList())
    val transactions: StateFlow<List<MoneyTransaction>> = _transactions.asStateFlow()

    private val _openingBalance = MutableStateFlow(OpeningBalanceStore.load(application))
    val openingBalance: StateFlow<OpeningBalance?> = _openingBalance.asStateFlow()

    private val _backupSafety = MutableStateFlow(loadBackupSafetyState())
    val backupSafety: StateFlow<BackupSafetyState> = _backupSafety.asStateFlow()

    init {
        refresh(runDailyBackup = true)
    }

    fun refresh(runDailyBackup: Boolean = false) {
        viewModelScope.launch {
            _transactions.value = withContext(Dispatchers.IO) { repository.getAll() }
            if (runDailyBackup && withContext(Dispatchers.IO) { AutoBackupManager.shouldRunDailyBackup(getApplication()) }) {
                triggerAutoBackup()
            }
        }
    }

    fun save(transaction: MoneyTransaction, onSaved: () -> Unit = {}) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { repository.save(transaction) }
            _transactions.value = withContext(Dispatchers.IO) { repository.getAll() }
            onSaved()
            triggerAutoBackup()
        }
    }

    fun delete(id: Long) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { repository.delete(id) }
            _transactions.value = withContext(Dispatchers.IO) { repository.getAll() }
            triggerAutoBackup()
        }
    }

    fun setOpeningBalance(openingBalance: OpeningBalance) {
        OpeningBalanceStore.save(getApplication(), openingBalance)
        _openingBalance.value = openingBalance
        triggerAutoBackup()
    }

    fun clearOpeningBalance() {
        OpeningBalanceStore.clear(getApplication())
        _openingBalance.value = null
        triggerAutoBackup()
    }

    fun exportBackup(uri: Uri, onResult: (Result<Unit>) -> Unit) {
        viewModelScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    BackupManager.export(getApplication(), _transactions.value, _openingBalance.value, uri)
                }
            }
            onResult(result)
        }
    }

    fun exportCsv(uri: Uri, onResult: (Result<Unit>) -> Unit) {
        viewModelScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    BackupManager.exportCsv(getApplication(), _transactions.value, uri)
                }
            }
            onResult(result)
        }
    }

    fun importBackup(uri: Uri, onResult: (Result<Int>) -> Unit) {
        viewModelScope.launch {
            val result = runCatching {
                val backup = withContext(Dispatchers.IO) {
                    BackupManager.import(getApplication(), uri)
                }
                withContext(Dispatchers.IO) { repository.replaceAll(backup.transactions) }
                if (backup.openingBalance != null) {
                    OpeningBalanceStore.save(getApplication(), backup.openingBalance)
                } else {
                    OpeningBalanceStore.clear(getApplication())
                }
                _openingBalance.value = backup.openingBalance
                _transactions.value = withContext(Dispatchers.IO) { repository.getAll() }
                backup.transactions.size
            }
            onResult(result)
            if (result.isSuccess) triggerAutoBackup()
        }
    }

    fun configureAutoBackup(uri: Uri, onResult: (Result<Unit>) -> Unit) {
        viewModelScope.launch {
            val result = runCatching {
                backupMutex.withLock {
                    withContext(Dispatchers.IO) {
                        AutoBackupManager.setFolder(getApplication(), uri)
                        AutoBackupManager.backupNow(
                            getApplication(),
                            _transactions.value,
                            _openingBalance.value
                        )
                    }
                }
            }
            _backupSafety.value = loadBackupSafetyState()
            onResult(result.map { Unit })
        }
    }

    fun disableAutoBackup() {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { AutoBackupManager.clearFolder(getApplication()) }
            _backupSafety.value = loadBackupSafetyState()
        }
    }

    fun runAutoBackup(onResult: (Result<Unit>) -> Unit) {
        viewModelScope.launch {
            val result = runCatching {
                backupMutex.withLock {
                    withContext(Dispatchers.IO) {
                        AutoBackupManager.backupNow(
                            getApplication(),
                            _transactions.value,
                            _openingBalance.value
                        )
                    }
                }
            }
            _backupSafety.value = loadBackupSafetyState()
            onResult(result.map { Unit })
        }
    }

    fun find(id: Long): MoneyTransaction? = _transactions.value.firstOrNull { it.id == id }

    private fun triggerAutoBackup() {
        if (AutoBackupManager.folderUri(getApplication()) == null) return

        viewModelScope.launch {
            runCatching {
                backupMutex.withLock {
                    withContext(Dispatchers.IO) {
                        AutoBackupManager.backupNow(
                            getApplication(),
                            _transactions.value,
                            _openingBalance.value
                        )
                    }
                }
            }
            _backupSafety.value = loadBackupSafetyState()
        }
    }

    private fun loadBackupSafetyState(): BackupSafetyState = BackupSafetyState(
        folderName = AutoBackupManager.folderLabel(getApplication()),
        lastBackupText = AutoBackupManager.formatLastBackup(getApplication()),
        lastError = AutoBackupManager.lastError(getApplication())
    )
}
