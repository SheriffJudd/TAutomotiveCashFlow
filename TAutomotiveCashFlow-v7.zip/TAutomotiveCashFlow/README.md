# T Automotive Cash Flow v7

Local/offline Android cash-flow tracker for T Automotive.

## v7 reliability update

- Permanent local SQLite transaction storage retained from previous versions.
- Automatic safety backups to a user-selected Android document folder.
- A verified ZIP backup is created after each data change while automatic backups are enabled.
- On app launch, a backup is also created if the last successful backup is more than 24 hours old.
- The newest 10 automatic backups are retained.
- Backups contain transactions, starting balance, receipt images, a CSV copy and a manifest.
- ZIPs are structurally validated before and after saving.
- Manual verified ZIP backup remains available.
- Separate CSV export for readable transaction records.
- Restore validates the backup before replacing the live transaction database.
- Existing v2-v6 backups remain restorable.
- Version 7.0 / versionCode 7; same application ID for in-place upgrades.

## Important

Automatic backups only work while Android allows the app access to the selected folder. A cloud-backed folder can be chosen if the installed storage provider supports Android's document-folder access. Keep more than one independent copy of important business records.
