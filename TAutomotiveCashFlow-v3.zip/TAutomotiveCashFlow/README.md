# T Automotive Cash Flow v3

A native Android cash-flow tracker for T Automotive.

## v3 highlights

- Polished finance-style dashboard
- Clear green income and red expense styling
- Monthly net profit hero card
- Quick Add Income / Add Expense buttons
- Six-month income vs expense chart
- Search and filter transaction list
- Cleaner transaction cards with receipt indicators
- Improved calendar with monthly totals and coloured day markers
- Refreshed Profit & Loss screen with yearly summary, monthly performance and category bars
- New T Automotive launcher icon
- Existing receipt attachments retained
- Existing ZIP backup / restore retained
- Same application ID so data is preserved when updating from the signed v2 build
- Version code 3 / version name 3.0

## Build

The project targets Android 35, minimum Android 8.0 (API 26), Kotlin/Compose, and Java 17.
