package com.tautomotive.cashflow.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tautomotive.cashflow.data.MoneyTransaction
import com.tautomotive.cashflow.data.TransactionType
import com.tautomotive.cashflow.ui.components.TransactionRow

private enum class TransactionFilter { ALL, INCOME, EXPENSE }

@Composable
fun TransactionsScreen(
    transactions: List<MoneyTransaction>,
    onEdit: (Long) -> Unit,
    onDelete: (Long) -> Unit
) {
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf(TransactionFilter.ALL) }

    val visible = transactions.filter { item ->
        val typeMatches = when (filter) {
            TransactionFilter.ALL -> true
            TransactionFilter.INCOME -> item.type == TransactionType.INCOME
            TransactionFilter.EXPENSE -> item.type == TransactionType.EXPENSE
        }
        val textMatches = query.isBlank() || listOf(
            item.description,
            item.category,
            item.customerSupplier,
            item.paymentMethod,
            item.notes
        ).any { it.contains(query, ignoreCase = true) }
        typeMatches && textMatches
    }

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Text(
            "Transactions",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 16.dp, bottom = 10.dp)
        )

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
            placeholder = { Text("Search description, customer, category…") },
            shape = RoundedCornerShape(16.dp)
        )

        Row(
            modifier = Modifier.padding(vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = filter == TransactionFilter.ALL,
                onClick = { filter = TransactionFilter.ALL },
                label = { Text("All") }
            )
            FilterChip(
                selected = filter == TransactionFilter.INCOME,
                onClick = { filter = TransactionFilter.INCOME },
                label = { Text("Income") }
            )
            FilterChip(
                selected = filter == TransactionFilter.EXPENSE,
                onClick = { filter = TransactionFilter.EXPENSE },
                label = { Text("Expenses") }
            )
        }

        Text(
            "${visible.size} ${if (visible.size == 1) "entry" else "entries"}",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        if (visible.isEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
                shape = RoundedCornerShape(18.dp)
            ) {
                Text(
                    if (transactions.isEmpty()) "No transactions recorded yet." else "No transactions match your search.",
                    modifier = Modifier.padding(20.dp)
                )
            }
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(visible, key = { it.id }) { transaction ->
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        TransactionRow(
                            transaction = transaction,
                            onClick = { onEdit(transaction.id) },
                            onDelete = { onDelete(transaction.id) },
                            modifier = Modifier.padding(horizontal = 12.dp)
                        )
                    }
                }
            }
        }
    }
}
