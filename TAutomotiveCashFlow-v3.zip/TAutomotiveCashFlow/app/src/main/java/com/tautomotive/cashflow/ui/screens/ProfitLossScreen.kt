package com.tautomotive.cashflow.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tautomotive.cashflow.data.MoneyTransaction
import com.tautomotive.cashflow.data.TransactionType
import com.tautomotive.cashflow.ui.components.formatMoney
import java.time.LocalDate
import java.time.Month
import java.time.format.TextStyle
import java.util.Locale
import kotlin.math.max

@Composable
fun ProfitLossScreen(transactions: List<MoneyTransaction>) {
    var year by remember { mutableIntStateOf(LocalDate.now().year) }
    val yearly = transactions.filter { it.date.year == year }
    val income = yearly.filter { it.type == TransactionType.INCOME }.sumOf { it.amountPence }
    val expenses = yearly.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amountPence }
    val profit = income - expenses

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Profit & Loss", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { year-- }) { Icon(Icons.Outlined.ChevronLeft, "Previous year") }
            Text(year.toString(), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            IconButton(onClick = { year++ }) { Icon(Icons.Outlined.ChevronRight, "Next year") }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(22.dp)
        ) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("Net profit", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                    formatMoney(profit),
                    style = MaterialTheme.typography.displaySmall,
                    fontWeight = FontWeight.Bold,
                    color = if (profit >= 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                )
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PnlMiniCard("Income", income, true, Modifier.weight(1f))
                    PnlMiniCard("Expenses", expenses, false, Modifier.weight(1f))
                }
            }
        }

        Text("Monthly performance", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        MonthlyProfitChart(yearly)

        Text("Monthly breakdown", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
            Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
                Row(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                    Text("Month", modifier = Modifier.weight(0.8f), fontWeight = FontWeight.Bold)
                    Text("In", modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
                    Text("Out", modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
                    Text("Net", modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
                }
                HorizontalDivider()
                Month.entries.forEachIndexed { index, month ->
                    val monthItems = yearly.filter { it.date.month == month }
                    val monthIncome = monthItems.filter { it.type == TransactionType.INCOME }.sumOf { it.amountPence }
                    val monthExpenses = monthItems.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amountPence }
                    val monthProfit = monthIncome - monthExpenses
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(month.getDisplayName(TextStyle.SHORT, Locale.UK), modifier = Modifier.weight(0.8f))
                        Text(formatMoney(monthIncome), modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                        Text(formatMoney(monthExpenses), modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                        Text(
                            formatMoney(monthProfit),
                            modifier = Modifier.weight(1f),
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = if (monthProfit >= 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                        )
                    }
                    if (index < Month.entries.lastIndex) HorizontalDivider()
                }
            }
        }

        Text("Expense categories", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        val categories = yearly
            .filter { it.type == TransactionType.EXPENSE }
            .groupBy { it.category }
            .mapValues { (_, values) -> values.sumOf { it.amountPence } }
            .toList()
            .sortedByDescending { it.second }

        if (categories.isEmpty()) {
            Text("No expenses recorded for $year.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            val maxCategory = max(1L, categories.maxOf { it.second })
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    categories.forEach { (category, total) ->
                        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(category, style = MaterialTheme.typography.bodyMedium)
                                Text(formatMoney(total), fontWeight = FontWeight.Bold)
                            }
                            Box(
                                Modifier
                                    .fillMaxWidth()
                                    .height(7.dp)
                                    .background(MaterialTheme.colorScheme.surfaceContainerHigh, RoundedCornerShape(50))
                            ) {
                                Box(
                                    Modifier
                                        .fillMaxWidth(total.toFloat() / maxCategory.toFloat())
                                        .height(7.dp)
                                        .background(MaterialTheme.colorScheme.error, RoundedCornerShape(50))
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PnlMiniCard(label: String, amount: Long, income: Boolean, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = if (income) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                formatMoney(amount),
                fontWeight = FontWeight.Bold,
                color = if (income) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
            )
        }
    }
}

@Composable
private fun MonthlyProfitChart(yearly: List<MoneyTransaction>) {
    val monthly = Month.entries.map { month ->
        val items = yearly.filter { it.date.month == month }
        val income = items.filter { it.type == TransactionType.INCOME }.sumOf { it.amountPence }
        val expenses = items.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amountPence }
        month to (income - expenses)
    }
    val maxAbs = max(1L, monthly.maxOfOrNull { kotlin.math.abs(it.second) } ?: 1L)

    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().height(140.dp).padding(horizontal = 12.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.Bottom
        ) {
            monthly.forEach { (month, value) ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    val barHeight = if (value == 0L) 3.dp else (82f * kotlin.math.abs(value).toFloat() / maxAbs.toFloat()).dp
                    Box(
                        Modifier
                            .width(10.dp)
                            .height(barHeight)
                            .background(
                                if (value >= 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                                RoundedCornerShape(topStart = 5.dp, topEnd = 5.dp)
                            )
                    )
                    Text(
                        month.getDisplayName(TextStyle.NARROW, Locale.UK),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 5.dp)
                    )
                }
            }
        }
    }
}
