# T Automotive Cash Flow v8

Version 8 adds PDF reporting and sharing while keeping the v7 data-safety features intact.

## v8 highlights
- Save cash-flow reports as PDF.
- Share a generated PDF through Android's share sheet (email, messaging apps, cloud storage, etc.).
- Report periods: current UK tax year, this month, all records, or a custom date range.
- PDF summary includes recorded income, expenses, net profit, transaction count, receipt count, starting balance and tracked balance at the report end date where applicable.
- Category breakdowns for income and expenses.
- Detailed transaction list including customer/supplier, vehicle registration, job reference, payment method, notes and receipt status.
- Optional receipt-image appendix. This is off by default to keep reports small.
- No estimates or projections are used.
- Existing automatic verified backups, manual ZIP backup/restore and CSV export remain unchanged.

Version code: 8
Version name: 8.0
