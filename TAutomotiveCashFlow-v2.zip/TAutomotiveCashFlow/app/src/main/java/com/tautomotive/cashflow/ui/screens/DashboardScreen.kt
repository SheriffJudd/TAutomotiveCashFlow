package com.tautomotive.cashflow.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tautomotive.cashflow.data.MoneyTransaction
import com.tautomotive.cashflow.data.TransactionType
import com.tautomotive.cashflow.ui.components.formatMoney
import java.time.LocalDate
import java.time.YearMonth

@Composable
fun DashboardScreen(transactions: List<MoneyTransaction>) {
    val today = LocalDate.now()
    val month = YearMonth.from(today)
    val monthTransactions = transactions.filter { YearMonth.from(it.date) == month }
    val income = monthTransactions.filter { it.type == TransactionType.INCOME }.sumOf { it.amountPence }
    val expenses = monthTransactions.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amountPence }
    val profit = income - expenses
    val lifetimeBalance = transactions.sumOf {
        if (it.type == TransactionType.INCOME) it.amountPence else -it.amountPence
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("T Automotive", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(
            month.month.name.lowercase().replaceFirstChar { it.uppercase() } + " ${month.year}",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        SummaryCard(
            "Recorded cash flow",
            formatMoney(lifetimeBalance),
            amountColor = if (lifetimeBalance >= 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
        )

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            SummaryCard(
                "Money in",
                formatMoney(income),
                Modifier.weight(1f),
                amountColor = MaterialTheme.colorScheme.primary
            )
            SummaryCard(
                "Money out",
                formatMoney(expenses),
                Modifier.weight(1f),
                amountColor = MaterialTheme.colorScheme.error
            )
        }

        SummaryCard(
            "Profit this month",
            formatMoney(profit),
            amountColor = if (profit >= 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
        )

        Spacer(Modifier.height(4.dp))
        Text("Recent activity", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)

        if (transactions.isEmpty()) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Text(
                    "No transactions yet. Tap + to record your first income or expense.",
                    modifier = Modifier.padding(18.dp)
                )
            }
        } else {
            transactions.take(5).forEach { transaction ->
                val incomeItem = transaction.type == TransactionType.INCOME
                Card(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(transaction.description.ifBlank { transaction.category }, fontWeight = FontWeight.SemiBold)
                            Text(transaction.category, style = MaterialTheme.typography.bodySmall)
                        }
                        Text(
                            (if (incomeItem) "+" else "−") + formatMoney(transaction.amountPence),
                            fontWeight = FontWeight.Bold,
                            color = if (incomeItem) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SummaryCard(
    title: String,
    value: String,
    modifier: Modifier = Modifier,
    amountColor: Color = MaterialTheme.colorScheme.onSurface
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Text(title, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(4.dp))
            Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = amountColor)
        }
    }
}
