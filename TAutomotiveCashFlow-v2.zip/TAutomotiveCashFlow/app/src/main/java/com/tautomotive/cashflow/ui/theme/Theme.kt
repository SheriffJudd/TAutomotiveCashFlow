package com.tautomotive.cashflow.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val IncomeGreen = Color(0xFF168A5B)
val IncomeGreenDark = Color(0xFF58D49A)
val ExpenseRed = Color(0xFFC53B42)
val ExpenseRedDark = Color(0xFFFF8A8F)

private val LightColors = lightColorScheme(
    primary = IncomeGreen,
    secondary = Color(0xFF296D8A),
    error = ExpenseRed,
    surface = Color(0xFFF8FAF9),
    surfaceVariant = Color(0xFFE9EFEC)
)

private val DarkColors = darkColorScheme(
    primary = IncomeGreenDark,
    secondary = Color(0xFF80C7E6),
    error = ExpenseRedDark
)

@Composable
fun CashFlowTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        content = content
    )
}
