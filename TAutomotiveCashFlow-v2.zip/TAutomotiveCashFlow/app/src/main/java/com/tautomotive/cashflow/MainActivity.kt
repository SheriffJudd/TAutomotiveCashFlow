package com.tautomotive.cashflow

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Summarize
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.tautomotive.cashflow.ui.CashFlowViewModel
import com.tautomotive.cashflow.ui.screens.AddEditTransactionScreen
import com.tautomotive.cashflow.ui.screens.CalendarScreen
import com.tautomotive.cashflow.ui.screens.DashboardScreen
import com.tautomotive.cashflow.ui.screens.ProfitLossScreen
import com.tautomotive.cashflow.ui.screens.SettingsScreen
import com.tautomotive.cashflow.ui.screens.TransactionsScreen
import com.tautomotive.cashflow.ui.theme.CashFlowTheme

class MainActivity : ComponentActivity() {
    private val viewModel: CashFlowViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CashFlowTheme {
                CashFlowApp(viewModel)
            }
        }
    }
}

private data class NavItem(val route: String, val label: String, val icon: @Composable () -> Unit)

@Composable
fun CashFlowApp(viewModel: CashFlowViewModel) {
    val navController = rememberNavController()
    val transactions by viewModel.transactions.collectAsState()
    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route.orEmpty()

    val navItems = listOf(
        NavItem("dashboard", "Home") { Icon(Icons.Outlined.Home, null) },
        NavItem("transactions", "Entries") { Icon(Icons.Outlined.ReceiptLong, null) },
        NavItem("calendar", "Calendar") { Icon(Icons.Outlined.CalendarMonth, null) },
        NavItem("pnl", "P&L") { Icon(Icons.Outlined.Summarize, null) },
        NavItem("settings", "Settings") { Icon(Icons.Outlined.Settings, null) }
    )
    val showMainChrome = !currentRoute.startsWith("add")

    Scaffold(
        bottomBar = {
            if (showMainChrome) {
                NavigationBar {
                    navItems.forEach { item ->
                        NavigationBarItem(
                            selected = currentRoute == item.route,
                            onClick = { navController.navigateTop(item.route) },
                            icon = item.icon,
                            label = { Text(item.label) }
                        )
                    }
                }
            }
        },
        floatingActionButton = {
            if (showMainChrome) {
                FloatingActionButton(onClick = { navController.navigate("add/0") }) {
                    Icon(Icons.Outlined.Add, contentDescription = "Add transaction")
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = "dashboard",
            modifier = Modifier.padding(padding)
        ) {
            composable("dashboard") { DashboardScreen(transactions) }
            composable("transactions") {
                TransactionsScreen(
                    transactions = transactions,
                    onEdit = { id -> navController.navigate("add/$id") },
                    onDelete = viewModel::delete
                )
            }
            composable("calendar") { CalendarScreen(transactions) }
            composable("pnl") { ProfitLossScreen(transactions) }
            composable("settings") {
                SettingsScreen(
                    onExport = viewModel::exportBackup,
                    onImport = viewModel::importBackup
                )
            }
            composable("add/{id}") { entry ->
                val id = entry.arguments?.getString("id")?.toLongOrNull() ?: 0L
                val existing = if (id == 0L) null else viewModel.find(id)
                AddEditTransactionScreen(
                    existing = existing,
                    onBack = { navController.popBackStack() },
                    onSave = { transaction ->
                        viewModel.save(transaction) {
                            navController.popBackStack()
                        }
                    }
                )
            }
        }
    }
}

private fun NavHostController.navigateTop(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}
