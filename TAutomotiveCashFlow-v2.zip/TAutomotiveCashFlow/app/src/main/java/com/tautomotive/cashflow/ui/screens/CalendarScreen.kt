package com.tautomotive.cashflow.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tautomotive.cashflow.data.MoneyTransaction
import com.tautomotive.cashflow.data.TransactionType
import com.tautomotive.cashflow.ui.components.formatMoney
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.TextStyle
import java.util.Locale

@Composable
fun CalendarScreen(transactions: List<MoneyTransaction>) {
    var month by remember { mutableStateOf(YearMonth.now()) }
    var selectedDate by remember { mutableStateOf(LocalDate.now()) }

    val first = month.atDay(1)
    val leading = first.dayOfWeek.value - 1
    val days = buildList<LocalDate?> {
        repeat(leading) { add(null) }
        for (day in 1..month.lengthOfMonth()) add(month.atDay(day))
    }
    val selectedTransactions = transactions.filter { it.date == selectedDate }

    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = {
                month = month.minusMonths(1)
                selectedDate = month.atDay(1)
            }) { Icon(Icons.Outlined.ChevronLeft, "Previous month") }

            Text(
                "${month.month.getDisplayName(TextStyle.FULL, Locale.UK)} ${month.year}",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )

            IconButton(onClick = {
                month = month.plusMonths(1)
                selectedDate = month.atDay(1)
            }) { Icon(Icons.Outlined.ChevronRight, "Next month") }
        }

        Row(modifier = Modifier.fillMaxWidth()) {
            listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun").forEach {
                Box(modifier = Modifier.weight(1f).padding(vertical = 6.dp), contentAlignment = Alignment.Center) {
                    Text(it, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                }
            }
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(7),
            modifier = Modifier.fillMaxWidth().weight(1f)
        ) {
            items(days) { date ->
                if (date == null) {
                    Box(Modifier.aspectRatio(0.82f))
                } else {
                    val dayTransactions = transactions.filter { it.date == date }
                    val income = dayTransactions.filter { it.type == TransactionType.INCOME }.sumOf { it.amountPence }
                    val expense = dayTransactions.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amountPence }
                    val selected = date == selectedDate

                    Column(
                        modifier = Modifier
                            .aspectRatio(0.82f)
                            .padding(2.dp)
                            .background(
                                if (selected) MaterialTheme.colorScheme.secondaryContainer
                                else MaterialTheme.colorScheme.surfaceContainerLow,
                                MaterialTheme.shapes.small
                            )
                            .clickable { selectedDate = date }
                            .padding(5.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(date.dayOfMonth.toString(), fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
                        if (income > 0) {
                            Text("+${shortMoney(income)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        }
                        if (expense > 0) {
                            Text("−${shortMoney(expense)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
        }

        Text(
            selectedDate.toString(),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
        )

        if (selectedTransactions.isEmpty()) {
            Text("No money in or out on this day.", style = MaterialTheme.typography.bodyMedium)
        } else {
            LazyColumn(modifier = Modifier.fillMaxWidth().weight(0.65f)) {
                items(selectedTransactions) { item ->
                    Card(modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(item.description.ifBlank { item.category }, modifier = Modifier.weight(1f))
                            Text(
                                (if (item.type == TransactionType.INCOME) "+" else "−") + formatMoney(item.amountPence),
                                fontWeight = FontWeight.Bold,
                                color = if (item.type == TransactionType.INCOME) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun shortMoney(pence: Long): String {
    val pounds = pence / 100.0
    return when {
        pounds >= 1000 -> "£%.1fk".format(Locale.UK, pounds / 1000)
        pounds % 1.0 == 0.0 -> "£%.0f".format(Locale.UK, pounds)
        else -> "£%.0f".format(Locale.UK, pounds)
    }
}
