package com.tautomotive.cashflow.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tautomotive.cashflow.data.BackupManager
import com.tautomotive.cashflow.data.CashFlowDatabase
import com.tautomotive.cashflow.data.CashFlowRepository
import com.tautomotive.cashflow.data.MoneyTransaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class CashFlowViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = CashFlowRepository(CashFlowDatabase(application))

    private val _transactions = MutableStateFlow<List<MoneyTransaction>>(emptyList())
    val transactions: StateFlow<List<MoneyTransaction>> = _transactions.asStateFlow()

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            _transactions.value = withContext(Dispatchers.IO) { repository.getAll() }
        }
    }

    fun save(transaction: MoneyTransaction, onSaved: () -> Unit = {}) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { repository.save(transaction) }
            _transactions.value = withContext(Dispatchers.IO) { repository.getAll() }
            onSaved()
        }
    }

    fun delete(id: Long) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { repository.delete(id) }
            _transactions.value = withContext(Dispatchers.IO) { repository.getAll() }
        }
    }

    fun exportBackup(uri: Uri, onResult: (Result<Unit>) -> Unit) {
        viewModelScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    BackupManager.export(getApplication(), _transactions.value, uri)
                }
            }
            onResult(result)
        }
    }

    fun importBackup(uri: Uri, onResult: (Result<Int>) -> Unit) {
        viewModelScope.launch {
            val result = runCatching {
                val restored = withContext(Dispatchers.IO) {
                    BackupManager.import(getApplication(), uri)
                }
                withContext(Dispatchers.IO) { repository.replaceAll(restored) }
                _transactions.value = withContext(Dispatchers.IO) { repository.getAll() }
                restored.size
            }
            onResult(result)
        }
    }

    fun find(id: Long): MoneyTransaction? = _transactions.value.firstOrNull { it.id == id }
}
