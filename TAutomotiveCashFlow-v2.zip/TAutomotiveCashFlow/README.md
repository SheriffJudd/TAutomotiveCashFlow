# T Automotive Cash Flow v2

Android cash-flow app for recording income and expenses.

## v2 additions
- Receipt photos from camera or gallery
- Receipt indicator on transactions
- Backup all transactions + receipts to a ZIP file
- Restore a backup from Settings
- Green income and red expense styling
- Settings tab
- Database migration from v1 data format

## Important signing note
The first APK was built as a temporary debug build. Before relying on the app for long-term records, set up one permanent Android signing key for future releases. Once the permanent key is established, keep it safe and use the same key for every later APK so updates install over the app without removing its data.
