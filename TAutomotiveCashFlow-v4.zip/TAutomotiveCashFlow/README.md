# T Automotive Cash Flow v4

A native Android cash-flow tracker for T Automotive.

## v4 highlights

- UK tax-year reporting from 6 April to 5 April
- Current tax year defaults to 6 April through today
- Tax-year-to-date card on the dashboard
- P&L can switch between Tax year, Calendar year, and Custom dates
- Tax-year P&L uses 6th-to-5th tax-month buckets
- Income is green, expenses are red, and net changes colour by result
- No estimates, projections, or guessed tax figures — recorded transactions only
- Transaction date filters: any date, this month, current tax year, or custom range
- Job / reference field
- Vehicle registration field
- Customer / supplier and payment method retained
- Search now includes customer, registration, job reference, category, and notes
- Receipt attachments retained
- ZIP backup / restore updated to include the new job and vehicle fields
- Database migration preserves existing v2/v3 data
- Same application ID and permanent signing flow, so it installs over signed v3
- Version code 4 / version name 4.0

## Build

The project targets Android 35, minimum Android 8.0 (API 26), Kotlin/Compose, and Java 17.
