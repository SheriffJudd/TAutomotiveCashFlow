package com.tautomotive.cashflow.data

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import java.time.LocalDate

object BackupManager {
    private const val JSON_NAME = "transactions.json"

    fun export(context: Context, transactions: List<MoneyTransaction>, outputUri: Uri) {
        val output = context.contentResolver.openOutputStream(outputUri) ?: error("Could not open backup destination")
        ZipOutputStream(output.buffered()).use { zip ->
            val array = JSONArray()
            transactions.forEach { t ->
                array.put(
                    JSONObject()
                        .put("id", t.id)
                        .put("type", t.type.name)
                        .put("amountPence", t.amountPence)
                        .put("category", t.category)
                        .put("description", t.description)
                        .put("date", t.date.toString())
                        .put("paymentMethod", t.paymentMethod)
                        .put("customerSupplier", t.customerSupplier)
                        .put("jobReference", t.jobReference)
                        .put("vehicleRegistration", t.vehicleRegistration)
                        .put("notes", t.notes)
                        .put("receiptFileName", t.receiptFileName)
                )
            }
            zip.putNextEntry(ZipEntry(JSON_NAME))
            zip.write(array.toString(2).toByteArray(Charsets.UTF_8))
            zip.closeEntry()

            transactions.map { it.receiptFileName }.filter { it.isNotBlank() }.distinct().forEach { name ->
                val file = ReceiptStorage.file(context, name)
                if (file.exists() && file.isFile) {
                    zip.putNextEntry(ZipEntry("receipts/${file.name}"))
                    file.inputStream().use { it.copyTo(zip) }
                    zip.closeEntry()
                }
            }
        }
    }

    fun import(context: Context, inputUri: Uri): List<MoneyTransaction> {
        val tempDir = File(context.cacheDir, "cashflow_restore_${System.currentTimeMillis()}").apply { mkdirs() }
        try {
            val basePath = tempDir.canonicalPath + File.separator
            val input = context.contentResolver.openInputStream(inputUri) ?: error("Could not open backup file")
            ZipInputStream(input.buffered()).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    val target = File(tempDir, entry.name)
                    if (!target.canonicalPath.startsWith(basePath)) error("Invalid backup file")
                    if (entry.isDirectory) {
                        target.mkdirs()
                    } else {
                        target.parentFile?.mkdirs()
                        target.outputStream().use { zip.copyTo(it) }
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }

            val jsonFile = File(tempDir, JSON_NAME)
            if (!jsonFile.exists()) error("Backup does not contain transactions")
            val array = JSONArray(jsonFile.readText())

            val receiptSourceDir = File(tempDir, "receipts")
            if (receiptSourceDir.exists()) {
                receiptSourceDir.listFiles()?.filter { it.isFile }?.forEach { source ->
                    source.copyTo(ReceiptStorage.file(context, source.name), overwrite = true)
                }
            }

            return buildList {
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val receipt = obj.optString("receiptFileName", "")
                    add(
                        MoneyTransaction(
                            id = obj.optLong("id", 0L),
                            type = TransactionType.valueOf(obj.getString("type")),
                            amountPence = obj.getLong("amountPence"),
                            category = obj.getString("category"),
                            description = obj.optString("description", ""),
                            date = LocalDate.parse(obj.getString("date")),
                            paymentMethod = obj.optString("paymentMethod", ""),
                            customerSupplier = obj.optString("customerSupplier", ""),
                            jobReference = obj.optString("jobReference", ""),
                            vehicleRegistration = obj.optString("vehicleRegistration", ""),
                            notes = obj.optString("notes", ""),
                            receiptFileName = if (receipt.isNotBlank() && ReceiptStorage.file(context, receipt).exists()) receipt else ""
                        )
                    )
                }
            }
        } finally {
            tempDir.deleteRecursively()
        }
    }
}
